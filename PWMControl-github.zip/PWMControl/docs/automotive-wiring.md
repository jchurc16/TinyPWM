# Automotive wiring plan — preliminary

![Automotive wiring plan](automotive-wiring.svg)

![Ignition relay and fused distribution](automotive-ignition-relay.svg)

This is a connection plan for the Waveshare ESP32-C3-LCD-1.47, pump **059121012A** (user-identified three-wire +12 V / ground / PWM), a **two-wire NTC sensor of currently unknown resistance**, and **ignition-switched operation**. It is not an installation-ready harness drawing: the pump connector cavity assignments and PWM electrical specification, sensor divider value, converter, fuse ratings and wire gauges remain to be verified. The amber pump-interface block and blue command path are deliberately unresolved. No firmware settings were changed for this diagram.

The [Pierburg/Motorservice catalogue](https://www.ms-motorservice.com/MediaAssets/2360531_pg_bf_50003865_web.pdf) cross-references 059 121 012 A to 7.01713.27.0. This cross-reference does **not** establish PWM voltage, frequency, pull-up arrangement, duty interpretation, or connector pin numbers. An authoritative specification for those properties was not found during this check. The current 25 kHz firmware setting is still a placeholder, not a verified setting for this pump.

## Ignition switching

The second sheet uses ignition-switched live as a low-current relay-coil trigger. Battery + goes through main feeder fuse F0 near the take-off, then to relay K1 terminal 30. Terminal 87 supplies the switched +12 V bus and splits into fused controller branch F1 and pump branch F2. F1 and F2 shown on both sheets are the **same two physical fuses**, not an additional pair. Relay terminal 86 receives the fused ignition trigger, and terminal 85 returns to vehicle negative. For the illustrated polarity, select an automotive relay with integral coil suppression and follow its datasheet; a diode-suppressed relay must be wired with the correct coil polarity. An unused 87a terminal on a changeover relay remains unconnected and insulated.

Select the relay contact rating for the pump's DC/inrush load and the aggregate branch current. The drawing uses conventional terminal markings, not physical connector positions. All three pump wires must be identified from the exact connector documentation; no assumed wire colours or numbered pump pinout are provided. Ignition off disconnects both the controller and pump supply in this plan, so it deliberately provides no after-run cooling. The plan assumes an additional standalone pump installation, not connection of this controller in parallel with an existing ECU PWM driver.

## Power and grounds

Use a separately fused controller supply through a protected automotive converter to regulated 5 V, then a correctly wired USB-C power lead to the board. A complete cable with the appropriate USB-C termination is preferable to bare USB-C connector pins. Do not connect the vehicle supply to the board's VSYS, USB, 3V3, or GPIO pins. Its schematic uses an MP1605 to generate the onboard 3.3 V rail; this is a low-voltage input device, not a vehicle-battery regulator. Use only one board power source during installation/testing; disconnect vehicle power before attaching a PC USB supply unless power sharing has been designed explicitly.

Automotive supply protection must account for reverse battery, overvoltage/load dump, jump start, overload, and the vehicle's transient environment. Fuse F1 close to its power take-off and size it to protect the controller branch cable and converter. A converter labelled only “12 V to 5 V” does not establish automotive transient suitability. Converter input range, protection thresholds, surge energy, thermal rating, and EMC filtering need to be selected together. If operation must continue through cranking, specify its minimum supply voltage and ride-through requirement; a buck converter can drop out during a low-voltage crank event.

The pump uses its own fused supply/return sized to its maximum current and inrush. F0/F1/F2/F-IGN and wire gauges cannot be specified without pump/converter/relay data and cable lengths; fuse ratings must protect the corresponding conductors and account for inrush. Do not pass pump current through the ESP32 board, breadboard ground rail, USB cable, or sensor return. For a non-isolated PWM interface, connect the controller and pump ground with the grounding arrangement specified by the pump manufacturer; the identified three-wire pump shares signal reference with its power ground. Keep the sensor return local to the controller and route it away from motor power wiring.

## Controller connections

| Board net | Connection |
| --- | --- |
| USB-C VBUS / GND | Regulated 5 V / converter return via a proper USB power lead |
| GPIO10 | PWM interface input; not the pump supply |
| GPIO0 | Resistive-divider measurement node |
| 3V3 | Top of the sensor divider resistor |
| GND | Sensor return, filter capacitor return, signal-interface reference |
| GPIO1 | Optional DS18B20 data, only if that backend is selected |

These are GPIO/net names, not connector cavity numbers. Verify the PCB labels against the manufacturer's schematic before wiring. The onboard display and BOOT button need no additional external wiring. The Android connection is Bluetooth.

## Sensor

The illustrated circuit uses the specified two-wire NTC sensor, assuming it is separate and electrically isolated from the vehicle ECU: board 3V3 → fixed resistor R1 → measurement node → NTC → board GND. Connect GPIO0 and a 100 nF capacitor to that node; the capacitor returns to board GND close to the ADC. R1 is marked **value to select** because the sensor resistance has not yet been measured. The current firmware example fixed resistor is 10 kΩ, which is not an installation specification. Select R1 using the actual sensor resistance over the entire working temperature range so the ADC voltage stays within the firmware's 50–2450 mV window. An open circuit can rise above that valid window even though the divider is supplied from 3.3 V. Enter measured calibration, fixed-resistor, and supply values through the app.

Do not splice this divider onto an existing ECU-driven temperature-sensor circuit. A one-wire, body-grounded automotive sender also needs its grounding and resistance characteristics assessed before substituting it for the illustrated isolated sensor.

If using a DS18B20 instead, omit the NTC divider: VDD → 3V3; GND → board GND; DQ → GPIO1; 4.7 kΩ pull-up from DQ to 3V3. Select DS18B20 in the app. Identify the probe wires from its supplier documentation rather than assuming wire colours.

## Pump interface still to select

The present firmware generates a 3.3 V electrical PWM command on GPIO10, at 25 kHz with `INVERT_GPIO = false`. Output is enabled. Startup/sensor faults command 100%; the pump's response to that command, reset, key-off and loss of signal must be checked against its documentation.

A pump that specifies a 5 V push-pull PWM signal can require a non-inverting TTL-input level buffer powered from regulated 5 V. An internally pulled-up/open-collector control input instead needs an appropriately rated sinking interface, with a corresponding firmware polarity setting. A 0–5 V analog control input needs a different output stage; the existing GPIO PWM output alone does not produce that analog command. A two-wire motor without an integrated PWM control input needs a motor power driver. Do not select any of these interfaces until the pump's input specification is available. Pump connector pin numbers/colours, optional tach/LIN/enable pins and termination of unused pins must come from that exact model's pinout.

## References

- [Waveshare board schematic and examples](https://docs.waveshare.com/ESP32-C3-LCD-1.47/Resources-And-Documents); project source revision `6e16df57c20b3b1651c1b6150a1c5b3c418a87f6`.
- [MPS MP1605 regulator](https://www.monolithicpower.com/en/mp1605.html).
- [TI automotive battery-input protection reference](https://www.ti.com/tool/TIDA-01167).
- [TI automotive cold-crank/front-end reference](https://www.ti.com/tool/TIDA-01179).
- [TI SN74AHCT125-Q1 buffer](https://www.ti.com/product/SN74AHCT125-Q1), relevant only if the pump specifies a compatible 5 V push-pull PWM input.
- Current wiring and behaviour: `PumpController/Config.h`, `TemperatureSensor.h`, and `PumpOutput.h`.
