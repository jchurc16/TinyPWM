# Pump configuration BLE protocol v1

Device name: `PWM Pump`. Service UUID: `3bb84c00-5ec6-4abc-9dc3-0f2b06384000`.

| Characteristic | UUID first segment | Access |
| --- | --- | --- |
| Settings | `3bb84c01` | Authenticated encrypted read, 100 bytes |
| Commands | `3bb84c02` | Authenticated encrypted write with response, at most 20 bytes |
| Status | `3bb84c03` | Authenticated encrypted read, 20 bytes |

The remaining UUID segments match the service. Numeric values are little-endian; floats are IEEE-754 binary32. The current C3 and C6 Arduino builds use NimBLE. Its 3.3.0 `BLESecurity` setters have missing static definitions, so `BleControl.h` sets the underlying host's security options directly and supplies the displayed PIN via `BLEServerCallbacks::onPassKeyRequest()`. No downloaded library is patched. Sessions require authenticated encryption and use no persistent bonds.

Core 3.3.0 dispatches both `onWrite(characteristic)` and the overload with connection information for each BLE write. The base connection-information overload forwards to the first overload. `BleControl.h` therefore overrides the second overload with a no-op, so each packet enters the transaction queue exactly once. Without this override, duplicate data packets fail the sequential-offset check and the curve is never committed.

## Settings payload

| Offset | Bytes | Meaning |
| --- | --- | --- |
| 0 | 1 | Version: 1 |
| 1 | 1 | Sensor: 0 NTC, 1 linear resistance, 2 DS18B20 |
| 2 | 1 | Point count: 2–8 |
| 3 | 1 | Reserved: 0 |
| 4 | 4 | Calibration T1, °C |
| 8 | 4 | Calibration R1, Ω |
| 12 | 4 | Calibration T2, °C |
| 16 | 4 | Calibration R2, Ω |
| 20 | 4 | Divider fixed resistance, Ω |
| 24 | 4 | Divider supply, mV |
| 28 | 4 | Stop temperature, °C |
| 32 | 4 | Ramp, percentage points/second |
| 36 + 8i | 4 | Point i temperature, °C |
| 40 + 8i | 4 | Point i duty, % |

Eight point slots are reserved. Unused slots are zeroed by encoders. Firmware validates a complete candidate before changing live state. Hardware and fault-policy fields are intentionally absent.

The current app/firmware accept curve temperatures from −20 through 110 °C and a stop threshold as low as −21 °C (strictly below the first point). The emergency full-output override is 110 °C. This extends the original example's 60 °C ceiling without changing the binary layout; update both app and firmware before using points above the old ceiling.

Current curve duty bounds are 5–100%; the last point is still required to be 100%. The original 35% floor was lowered in app 0.2.2 and its matching firmware. This is a validation change with the same payload layout. Normal stop remains a 0% command.

## Write transaction

1. BEGIN: `01`, transaction ID u16, total length u16 (100), CRC32 u32 (9 bytes).
2. DATA: `02`, same ID u16, exact next byte offset u16, 1–15 payload bytes (6–20 bytes).
3. COMMIT: `03`, same ID u16 (3 bytes).

Use the standard CRC32/ISO-HDLC polynomial (`0xEDB88320` reflected, initial/final XOR `0xFFFFFFFF`) over all 100 payload bytes, as in Java's `CRC32`. Frames must be ordered. The transaction expires after more than 10 seconds between frames. A new BEGIN abandons an earlier partial transfer. Disconnect, malformed frames, CRC mismatch, or a closed setup window discards staging.

BLE callbacks enqueue bounded frames. The main loop drains at most four per iteration, validates the assembled candidate, writes one checksummed NVS blob, and only then publishes/applies the new settings. A GATT response confirms receipt of an individual frame, not durable storage. Only status result 1 with the matching transaction ID, followed by settings readback, confirms the app's save.

NVS namespace: `pump-settings`, key: `config`; value: CRC32 u32 followed by the 100-byte settings payload. Settings are validated again on boot. Missing/invalid data falls back to `Config.h` defaults. Do not continuously autosave slider movements; the app saves only when explicitly requested.

## Status payload

| Offset | Bytes | Meaning |
| --- | --- | --- |
| 0 | 1 | Version: 1 |
| 1 | 1 | Flags: bit 0 sensor valid, 1 output enabled, 2 demo, 3 setup window open, 4 PWM initialized |
| 2 | 1 | State: 0 off, 1 starting, 2 running, 3 sensor fault, 4 overtemperature |
| 3 | 1 | Transaction result (below) |
| 4 | 4 | Temperature °C; NaN when invalid |
| 8 | 4 | Applied PWM command % |
| 12 | 4 | Calculated pump demand % |
| 16 | 2 | Last command transaction ID |
| 18 | 2 | Setup seconds remaining |

Results: 0 idle/commit assembled, 1 saved, 2 invalid settings, 3 locked, 4 storage failure, 5 queue overflow/busy, 6 malformed/incomplete/expired/CRC-failed transfer, 7 staging. Results persist until the next command or transport error. A new transaction's BEGIN sets result 7; save clients must match the transaction ID and read back the settings before reporting success.

Hold BOOT (GPIO9) after boot for two seconds to open a 120-second write window. Holding it continuously does not repeatedly extend the window; release and hold again. Setup closes on reboot. The phone cannot open the window or enable hardware PWM through this protocol. Existing control, emergency overrides and sensor fault handling continue independently of the BLE connection.
