package com.pwmcontrol.companion;

import java.util.List;

/** Touch-independent constraints shared by the graph and its tests. */
public final class CurveEditor {
    private CurveEditor() {}
    public static int insertPoint(List<Settings.Point> points) {
        if (points.size() < 2 || points.size() >= Settings.MAX_POINTS)
            throw new IllegalArgumentException("Use between two and eight curve points.");
        int best = -1; float bestScore = -1;
        for (int i = 1; i < points.size(); i++) {
            float dt = points.get(i).temperature() - points.get(i-1).temperature();
            if (dt < 0.2f) continue;
            float dx = dt / (Settings.MAX_TEMPERATURE - Settings.MIN_TEMPERATURE);
            float dy = (points.get(i).percent() - points.get(i-1).percent()) / 100;
            float score = dx * dx + dy * dy;
            if (score > bestScore) { best = i; bestScore = score; }
        }
        if (best < 0) throw new IllegalArgumentException("Make room between temperatures before adding a point.");
        Settings.Point a = points.get(best-1), b = points.get(best);
        points.add(best, new Settings.Point((a.temperature()+b.temperature())/2, (a.percent()+b.percent())/2));
        return best;
    }
    public static Settings.Point move(List<Settings.Point> points, int index, float temperature, float duty) {
        Settings.Point original = points.get(index);
        if (!Float.isFinite(temperature) || !Float.isFinite(duty)) return original;
        float low = Math.max(Settings.MIN_TEMPERATURE, index == 0 ? Settings.MIN_TEMPERATURE : points.get(index - 1).temperature() + 0.1f);
        float high = Math.min(Settings.MAX_TEMPERATURE, index + 1 == points.size() ? Settings.MAX_TEMPERATURE : points.get(index + 1).temperature() - 0.1f);
        low = (float) Math.ceil(low * 10 - 0.0001f) / 10;
        high = (float) Math.floor(high * 10 + 0.0001f) / 10;
        if (low > high) return original; // Very tightly spaced numeric points remain editable in their fields.
        float minDuty = index == 0 ? Settings.MIN_DUTY : points.get(index - 1).percent();
        float maxDuty = index + 1 == points.size() ? 100 : points.get(index + 1).percent();
        float t = Math.max(low, Math.min(high, Math.round(temperature * 10) / 10.0f));
        float p = index + 1 == points.size() ? 100 : Math.max(minDuty, Math.min(maxDuty, Math.round(duty)));
        return new Settings.Point(t, p);
    }
    public static float stopForStartMove(float temperature, float originalGap) {
        int temperatureTenths = Math.round(temperature * 10);
        int gapTenths = Math.max(1, Math.round(originalGap * 10));
        return Math.max(Math.round(Settings.MIN_STOP_TEMPERATURE * 10), temperatureTenths - gapTenths) / 10.0f;
    }
}
