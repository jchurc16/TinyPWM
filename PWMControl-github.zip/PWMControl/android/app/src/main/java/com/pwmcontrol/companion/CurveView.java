package com.pwmcontrol.companion;

import android.content.Context;
import android.graphics.*;
import android.view.View;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import java.util.ArrayList;
import java.util.List;

public final class CurveView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private List<Settings.Point> points = new ArrayList<>();
    private float stop = 28;
    private Float liveTemperature;
    private int selected = -1, highlighted = -1, pointer = -1;
    private float downX, downY, originalX, originalY, originalStopGap;
    private boolean dragging, editable = true;
    private final int touchSlop;
    public interface OnPointDraggedListener { void moved(int index, Settings.Point point, float stopTemperature); }
    private OnPointDraggedListener listener;
    public CurveView(Context context) {
        super(context);
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        setClickable(true);
        setContentDescription("Editable temperature to PWM curve. Drag points or use the numeric fields below.");
    }
    public void setOnPointDraggedListener(OnPointDraggedListener listener) { this.listener = listener; }
    public void highlightPoint(int index) { highlighted = index >= 0 && index < points.size() ? index : -1; invalidate(); }
    public void setEditingAllowed(boolean allowed) { editable = allowed; if (!allowed) finishDrag(); }
    public void setCurve(List<Settings.Point> points, float stop) {
        finishDrag(); this.points = new ArrayList<>(points); this.stop = stop;
        setContentDescription("Editable temperature to PWM curve with " + points.size() + " points. Drag points or use the numeric fields below.");
        if (highlighted >= points.size()) highlighted = -1;
        invalidate();
    }
    public void setTemperature(Float temperature) { liveTemperature = temperature; invalidate(); }
    private float dp(float value) { return value * getResources().getDisplayMetrics().density; }
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (points.size() < 2) return;
        float left = dp(38), right = getWidth() - dp(14), top = dp(20), bottom = getHeight() - dp(32);
        float low = Settings.MIN_TEMPERATURE, high = Settings.MAX_TEMPERATURE;
        if (!Float.isFinite(low) || !Float.isFinite(high) || high <= low) return;
        paint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL)); paint.setTextSize(dp(10));
        for (int value = 0; value <= 100; value += 25) {
            float y = bottom - (bottom - top) * value / 100;
            paint.setColor(Color.rgb(43, 59, 79)); paint.setStrokeWidth(dp(1)); canvas.drawLine(left, y, right, y, paint);
            paint.setColor(Color.rgb(160, 179, 198)); canvas.drawText(value + "%", dp(1), y + dp(4), paint);
        }
        for (int i = 0; i <= 4; i++) {
            float t = low + (high - low) * i / 4;
            float x = left + (right - left) * i / 4;
            String tick = String.format(java.util.Locale.US, t == (int)t ? "%.0f°C" : "%.1f°C", t);
            float textX = Math.max(0, Math.min(getWidth() - paint.measureText(tick), x - paint.measureText(tick) / 2));
            canvas.drawText(tick, textX, bottom + dp(22), paint);
        }
        Path curve = new Path();
        float x0 = x(points.get(0).temperature(), low, high, left, right);
        curve.moveTo(left, bottom); curve.lineTo(x0, bottom);
        curve.lineTo(x0, y(points.get(0).percent(), top, bottom));
        for (Settings.Point p : points) curve.lineTo(x(p.temperature(), low, high, left, right), y(p.percent(), top, bottom));
        curve.lineTo(right, y(points.get(points.size() - 1).percent(), top, bottom));
        paint.setColor(Color.rgb(85, 214, 190)); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(3));
        canvas.drawPath(curve, paint); paint.setStyle(Paint.Style.FILL);
        for (int i = 0; i < points.size(); i++) {
            Settings.Point p = points.get(i);
            boolean active = i == selected || i == highlighted;
            float cx = x(p.temperature(), low, high, left, right), cy = y(p.percent(), top, bottom);
            if (active) {
                paint.setColor(Color.argb(65, 85, 214, 190));
                canvas.drawCircle(cx, cy, dp(19), paint);
            }
            paint.setColor(Color.rgb(85, 214, 190));
            canvas.drawCircle(cx, cy, dp(active ? 12 : 10), paint);
            paint.setColor(Color.rgb(11,18,32)); paint.setTextSize(dp(10)); paint.setTypeface(Typeface.DEFAULT_BOLD);
            String number = Integer.toString(i+1);
            canvas.drawText(number, cx - paint.measureText(number)/2, cy - (paint.ascent()+paint.descent())/2, paint);
        }
        int active = selected >= 0 ? selected : highlighted;
        paint.setColor(Color.WHITE); paint.setTextSize(dp(11)); paint.setTypeface(Typeface.DEFAULT);
        String caption = points.size() + " points · drag to edit";
        if (active >= 0) {
            Settings.Point p = points.get(active);
            caption = String.format(java.util.Locale.US, "Point %d of %d: %.1f°C / %.1f%%", active+1, points.size(), p.temperature(), p.percent());
        }
        canvas.drawText(caption, left, dp(12), paint);
        if (liveTemperature != null && Float.isFinite(liveTemperature)) {
            float position = x(Math.max(low, Math.min(high, liveTemperature)), low, high, left, right);
            paint.setColor(Color.rgb(255, 204, 115)); paint.setStrokeWidth(dp(1)); canvas.drawLine(position, top, position, bottom, paint);
        }
    }
    @Override public boolean onTouchEvent(MotionEvent event) {
        if (!isEnabled() || !editable || points.size() < 2) { finishDrag(); return false; }
        float left = dp(38), right = getWidth() - dp(14), top = dp(20), bottom = getHeight() - dp(32);
        if (right <= left || bottom <= top) return false;
        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            float best = dp(26) * dp(26);
            selected = -1;
            for (int i = 0; i < points.size(); i++) {
                Settings.Point p = points.get(i);
                float px = x(p.temperature(), Settings.MIN_TEMPERATURE, Settings.MAX_TEMPERATURE, left, right);
                float py = y(p.percent(), top, bottom);
                float distance = (px - event.getX()) * (px - event.getX()) + (py - event.getY()) * (py - event.getY());
                if (distance <= best) { best = distance; selected = i; originalX = px; originalY = py; }
            }
            if (selected < 0) return false; // Empty graph area still scrolls the surrounding page.
            highlighted = -1;
            pointer = event.getPointerId(0); downX = event.getX(); downY = event.getY(); dragging = false;
            originalStopGap = points.get(0).temperature() - stop;
            if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
            invalidate(); return true;
        }
        if (selected < 0) return false;
        int position = event.findPointerIndex(pointer);
        if (event.getActionMasked() == MotionEvent.ACTION_CANCEL || position < 0 ||
                (event.getActionMasked() == MotionEvent.ACTION_POINTER_UP && event.getPointerId(event.getActionIndex()) == pointer)) {
            finishDrag(); return true;
        }
        if (event.getActionMasked() == MotionEvent.ACTION_MOVE || event.getActionMasked() == MotionEvent.ACTION_UP) {
            float dx = event.getX(position) - downX, dy = event.getY(position) - downY;
            dragging |= dx * dx + dy * dy > touchSlop * touchSlop;
            if (dragging) {
                float temperature = Settings.MIN_TEMPERATURE + (originalX + dx - left) / (right - left) *
                        (Settings.MAX_TEMPERATURE - Settings.MIN_TEMPERATURE);
                float duty = (bottom - originalY - dy) / (bottom - top) * 100;
                Settings.Point p = CurveEditor.move(points, selected, temperature, duty);
                points.set(selected, p);
                if (selected == 0) stop = CurveEditor.stopForStartMove(p.temperature(), originalStopGap);
                if (listener != null) listener.moved(selected, p, stop);
                invalidate();
            }
            if (event.getActionMasked() == MotionEvent.ACTION_UP) { if (!dragging) performClick(); finishDrag(); }
            return true;
        }
        return true;
    }
    @Override public boolean performClick() { super.performClick(); return true; }
    @Override public void setEnabled(boolean enabled) { super.setEnabled(enabled); if (!enabled) finishDrag(); }
    private void finishDrag() {
        selected = pointer = -1; dragging = false;
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
        invalidate();
    }
    private float x(float t, float min, float max, float left, float right) { return left + (t - min) / (max - min) * (right - left); }
    private float y(float duty, float top, float bottom) { return bottom - duty / 100 * (bottom - top); }
}
