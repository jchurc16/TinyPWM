package com.pwmcontrol.companion;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.CRC32;

/** Version 1 wire format; keep aligned with ControllerSettings.h. */
public final class Settings {
    public static final int SIZE = 100, MAX_POINTS = 8;
    public static final float MIN_TEMPERATURE = -20, MAX_TEMPERATURE = 110;
    public static final float MIN_STOP_TEMPERATURE = -21, MIN_DUTY = 5;
    public int sensorType = 0;
    public float t1 = 25, r1 = 10000, t2 = 50, r2 = 3600;
    public float fixedOhms = 10000, supplyMv = 3300, stop = 28, ramp = 10;
    public final List<Point> points = new ArrayList<>();
    public record Point(float temperature, float percent) {}

    public Settings() { points.add(new Point(30, 35)); points.add(new Point(50, 100)); }

    public void validate() {
        require(sensorType >= 0 && sensorType <= 2, "Choose a supported sensor type.");
        require(points.size() >= 2 && points.size() <= MAX_POINTS, "Use 2 to 8 curve points.");
        require(range(t1, -20, 110) && range(t2, -20, 110) && Math.abs(t2 - t1) >= 0.1f,
                "Calibration temperatures must differ by at least 0.1 °C and be between -20 and 110 °C.");
        require(range(r1, 1, 10000000) && range(r2, 1, 10000000) && r1 != r2,
                "Calibration resistances must differ and be between 1 Ω and 10 MΩ.");
        if (sensorType == 0) {
            double beta = Math.log(r1 / r2) / (1 / (t1 + 273.15) - 1 / (t2 + 273.15));
            require(Double.isFinite(beta) && beta > 0, "An NTC's resistance must decrease as temperature increases.");
        }
        require(range(fixedOhms, 100, 1000000), "Fixed resistor must be 100 Ω to 1 MΩ.");
        require(range(supplyMv, 3000, 3600), "Divider supply must be 3000 to 3600 mV.");
        require(range(stop, MIN_STOP_TEMPERATURE, MAX_TEMPERATURE) && stop < points.get(0).temperature,
                "Stop temperature must be below the first curve point and at least -21 °C.");
        require(range(ramp, 0.1f, 100), "Ramp must be 0.1 to 100 percentage points per second.");
        for (int i = 0; i < points.size(); i++) {
            Point point = points.get(i);
            require(range(point.temperature, MIN_TEMPERATURE, MAX_TEMPERATURE), "Curve temperatures must be between -20 and 110 °C.");
            require(range(point.percent, MIN_DUTY, 100), "Curve duty must be between 5% and 100%.");
            if (i > 0) require(point.temperature > points.get(i - 1).temperature && point.percent >= points.get(i - 1).percent,
                    "Enter curve points in increasing temperature order, with duty staying level or rising.");
        }
        require(points.get(points.size() - 1).percent == 100, "The last curve point must command 100%.");
    }

    public byte[] encode() {
        validate();
        ByteBuffer b = ByteBuffer.allocate(SIZE).order(ByteOrder.LITTLE_ENDIAN);
        b.put((byte) 1).put((byte) sensorType).put((byte) points.size()).put((byte) 0);
        for (float v : new float[]{t1, r1, t2, r2, fixedOhms, supplyMv, stop, ramp}) b.putFloat(v);
        for (Point p : points) b.putFloat(p.temperature).putFloat(p.percent);
        return b.array();
    }

    public static Settings decode(byte[] data) {
        require(data.length == SIZE, "Unexpected settings length. Check firmware/app versions.");
        ByteBuffer b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        require(b.get() == 1, "Unsupported settings version.");
        Settings s = new Settings(); s.sensorType = Byte.toUnsignedInt(b.get());
        int count = Byte.toUnsignedInt(b.get());
        require(b.get() == 0 && count >= 2 && count <= 8, "Invalid controller settings header.");
        s.t1 = b.getFloat(); s.r1 = b.getFloat(); s.t2 = b.getFloat(); s.r2 = b.getFloat();
        s.fixedOhms = b.getFloat(); s.supplyMv = b.getFloat(); s.stop = b.getFloat(); s.ramp = b.getFloat();
        s.points.clear();
        for (int i = 0; i < count; i++) s.points.add(new Point(b.getFloat(), b.getFloat()));
        s.validate(); return s;
    }

    public static List<byte[]> frames(byte[] settings, int transaction) {
        require(settings.length == SIZE, "Wrong transfer size.");
        CRC32 crc = new CRC32(); crc.update(settings);
        List<byte[]> frames = new ArrayList<>();
        frames.add(ByteBuffer.allocate(9).order(ByteOrder.LITTLE_ENDIAN).put((byte) 1)
                .putShort((short) transaction).putShort((short) SIZE).putInt((int) crc.getValue()).array());
        for (int offset = 0; offset < SIZE; offset += 15) {
            int length = Math.min(15, SIZE - offset);
            frames.add(ByteBuffer.allocate(5 + length).order(ByteOrder.LITTLE_ENDIAN).put((byte) 2)
                    .putShort((short) transaction).putShort((short) offset).put(settings, offset, length).array());
        }
        frames.add(ByteBuffer.allocate(3).order(ByteOrder.LITTLE_ENDIAN).put((byte) 3).putShort((short) transaction).array());
        return frames;
    }

    private static boolean range(float x, float min, float max) { return Float.isFinite(x) && x >= min && x <= max; }
    private static void require(boolean condition, String message) { if (!condition) throw new IllegalArgumentException(message); }
}
