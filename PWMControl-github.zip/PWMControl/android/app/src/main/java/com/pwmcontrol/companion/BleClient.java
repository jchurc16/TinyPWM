package com.pwmcontrol.companion;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.*;
import android.bluetooth.le.*;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.*;

/** All state/operations are confined to the UI thread. Exactly one GATT operation runs at a time. */
// Permission checks and SecurityException handling surround BLE entry points;
// callbacks run only for operations started after those checks.
@SuppressLint("MissingPermission")
public final class BleClient {
    public static final UUID SERVICE = UUID.fromString("3bb84c00-5ec6-4abc-9dc3-0f2b06384000");
    private static final UUID SETTINGS = UUID.fromString("3bb84c01-5ec6-4abc-9dc3-0f2b06384000");
    private static final UUID COMMAND = UUID.fromString("3bb84c02-5ec6-4abc-9dc3-0f2b06384000");
    private static final UUID STATUS = UUID.fromString("3bb84c03-5ec6-4abc-9dc3-0f2b06384000");
    public interface Listener {
        void message(String text);
        void device(BluetoothDevice device, String name);
        void connection(boolean connected);
        void settings(Settings settings);
        void status(Telemetry status);
        void saved();
        void saveState(boolean saving);
    }
    public record Telemetry(int flags, int state, int result, float temperature, float output,
                            float demand, int transaction, int windowSeconds) {
        public boolean sensorValid() { return (flags & 1) != 0; }
        public boolean outputEnabled() { return (flags & 2) != 0; }
        public boolean demo() { return (flags & 4) != 0; }
        public boolean unlocked() { return (flags & 8) != 0; }
        public boolean pwmReady() { return (flags & 16) != 0; }
    }
    private record Op(UUID uuid, byte[] write) {}
    private final Activity activity;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final BluetoothAdapter adapter;
    private final ArrayDeque<Op> queue = new ArrayDeque<>();
    private BluetoothGatt gatt;
    private Op active;
    private boolean scanning, connected, loaded, saving, verifying, polling = true;
    private int transaction;
    private long saveDeadline;
    private byte[] expected;

    public BleClient(Activity activity, Listener listener) {
        this.activity = activity; this.listener = listener;
        BluetoothManager manager = (BluetoothManager) activity.getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager == null ? null : manager.getAdapter();
    }
    public boolean permissions() {
        if (Build.VERSION.SDK_INT >= 31)
            return activity.checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                   activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED;
        return activity.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }
    public void requestPermissions() {
        activity.requestPermissions(Build.VERSION.SDK_INT >= 31 ?
                new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT} :
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 10);
    }
    public void scan() {
        if (!permissions()) { requestPermissions(); return; }
        if (adapter == null || !adapter.isEnabled()) { listener.message("Enable Bluetooth on your phone, then scan again."); return; }
        stopScan(); disconnect(false);
        try {
            BluetoothLeScanner scanner = adapter.getBluetoothLeScanner();
            if (scanner == null) { listener.message("Bluetooth scanning is unavailable."); return; }
            scanning = true;
            scanner.startScan(Collections.singletonList(new ScanFilter.Builder().setServiceUuid(new ParcelUuid(SERVICE)).build()),
                    new ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build(), scans);
            listener.message("Scanning for PWM Pump controllers…");
            main.postDelayed(stopScanTask, 12000);
        } catch (SecurityException | IllegalStateException e) { listener.message("Bluetooth scan could not start. Check permissions and Bluetooth."); }
    }
    private final Runnable stopScanTask = this::scanFinished;
    private void scanFinished() {
        stopScan(); listener.message("Scan finished. Choose a controller. If none appear, check power and Bluetooth permissions.");
    }
    public void stopScan() {
        main.removeCallbacks(stopScanTask);
        if (scanning && permissions() && adapter != null) {
            try { BluetoothLeScanner scanner = adapter.getBluetoothLeScanner(); if (scanner != null) scanner.stopScan(scans); }
            catch (SecurityException | IllegalStateException ignored) {}
        }
        scanning = false;
    }
    private final ScanCallback scans = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) {
            main.post(() -> { if (scanning) listener.device(result.getDevice(), result.getScanRecord() == null ?
                    "PWM Pump" : result.getScanRecord().getDeviceName()); });
        }
        @Override public void onScanFailed(int errorCode) {
            main.post(() -> { stopScan(); listener.message("BLE scan failed (" + errorCode + "). Try again after a few seconds."); });
        }
    };
    public void connect(BluetoothDevice device) {
        if (!permissions()) { requestPermissions(); return; }
        stopScan(); disconnect(false);
        listener.message("Connecting. Hold BOOT for 2 seconds; enter the screen PIN if Android asks to pair.");
        try {
            gatt = device.connectGatt(activity, false, callbacks, BluetoothDevice.TRANSPORT_LE);
            if (gatt == null) { listener.message("Could not start a Bluetooth connection."); return; }
            main.postDelayed(timeout, 60000);
        } catch (SecurityException e) { listener.message("Bluetooth connection permission is required."); }
    }
    public void reload() {
        if (!connected || saving) return;
        if (active != null || !queue.isEmpty()) { listener.message("Wait for the current Bluetooth read to finish."); return; }
        enqueue(new Op(SETTINGS, null));
    }
    public void save(Settings settings) {
        if (!connected || !loaded || saving) return;
        expected = settings.encode(); saving = true; verifying = false;
        transaction = (transaction + 1) & 0xffff;
        saveDeadline = SystemClock.elapsedRealtime() + 25000;
        listener.saveState(true); listener.message("Sending settings; waiting for controller validation and flash save…");
        // A status read already in progress completes first. Acknowledgement is checked only after all writes.
        for (byte[] frame : Settings.frames(expected, transaction)) queue.add(new Op(COMMAND, frame));
        next();
    }
    private void enqueue(Op op) { queue.add(op); next(); }
    private void next() {
        if (active != null || queue.isEmpty() || gatt == null || !connected) return;
        active = queue.remove();
        BluetoothGattService service = gatt.getService(SERVICE);
        BluetoothGattCharacteristic characteristic = service == null ? null : service.getCharacteristic(active.uuid);
        if (characteristic == null) { fail("Controller is missing a required Bluetooth characteristic."); return; }
        boolean started;
        try {
            if (active.write == null) started = gatt.readCharacteristic(characteristic);
            else if (Build.VERSION.SDK_INT >= 33) started = gatt.writeCharacteristic(characteristic, active.write,
                    BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothStatusCodes.SUCCESS;
            else {
                characteristic.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT);
                characteristic.setValue(active.write); started = gatt.writeCharacteristic(characteristic);
            }
        } catch (SecurityException e) { fail("Bluetooth permission was revoked."); return; }
        if (!started) { fail("Bluetooth operation could not start. Disconnect and reconnect."); return; }
        main.removeCallbacks(timeout); main.postDelayed(timeout, 60000);
    }
    private final Runnable timeout = () -> fail("Bluetooth timed out. Any save is unconfirmed; reconnect and reload settings.");
    private final Runnable poll = new Runnable() {
        @Override public void run() {
            if (!connected || !polling) return;
            if (saving && SystemClock.elapsedRealtime() > saveDeadline) {
                fail("Save not confirmed. Reconnect and reload settings before retrying.");
                return;
            }
            if (active == null && queue.isEmpty()) enqueue(new Op(STATUS, null));
            main.postDelayed(this, 1000);
        }
    };
    public void setPolling(boolean enabled) {
        polling = enabled; main.removeCallbacks(poll);
        if (enabled && connected) main.post(poll);
    }
    public void disconnect() { stopScan(); disconnect(true); }
    private void disconnect(boolean announce) {
        boolean unconfirmed = saving;
        main.removeCallbacks(timeout); main.removeCallbacks(poll);
        queue.clear(); active = null; connected = loaded = saving = verifying = false;
        BluetoothGatt old = gatt; gatt = null;
        if (old != null) { try { old.disconnect(); old.close(); } catch (SecurityException ignored) {} }
        listener.connection(false); listener.saveState(false);
        if (announce) listener.message(unconfirmed ? "Disconnected. Save not confirmed; reconnect and reload." : "Disconnected. The controller continues using its saved settings.");
    }
    private void fail(String message) { disconnect(false); listener.message(message); }
    public void close() { stopScan(); disconnect(false); main.removeCallbacksAndMessages(null); }

    private final BluetoothGattCallback callbacks = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt source, int status, int state) {
            main.post(() -> {
                if (source != gatt) return;
                if (status == BluetoothGatt.GATT_SUCCESS && state == BluetoothProfile.STATE_CONNECTED) {
                    try { if (!source.discoverServices()) fail("Service discovery could not start."); }
                    catch (SecurityException e) { fail("Bluetooth permission was revoked."); }
                } else if (state == BluetoothProfile.STATE_DISCONNECTED || status != BluetoothGatt.GATT_SUCCESS)
                    fail("Bluetooth disconnected (" + status + "). Any pending save is unconfirmed; reconnect to reload.");
            });
        }
        @Override public void onServicesDiscovered(BluetoothGatt source, int status) {
            main.post(() -> {
                if (source != gatt) return;
                if (status != BluetoothGatt.GATT_SUCCESS || source.getService(SERVICE) == null) { fail("This device is not a compatible pump controller."); return; }
                connected = true; listener.connection(true);
                listener.message("Reading controller settings. Use the PIN on the board screen if asked to pair.");
                enqueue(new Op(SETTINGS, null));
                queue.add(new Op(STATUS, null));
                if (polling) main.postDelayed(poll, 1000);
            });
        }
        @Override public void onCharacteristicRead(BluetoothGatt source, BluetoothGattCharacteristic c, int status) {
            if (Build.VERSION.SDK_INT < 33) {
                byte[] value = c.getValue();
                readComplete(source, c.getUuid(), value == null ? new byte[0] : value.clone(), status);
            }
        }
        @Override public void onCharacteristicRead(BluetoothGatt source, BluetoothGattCharacteristic c, byte[] value, int status) {
            readComplete(source, c.getUuid(), value.clone(), status);
        }
        @Override public void onCharacteristicWrite(BluetoothGatt source, BluetoothGattCharacteristic c, int status) {
            main.post(() -> {
                if (source != gatt || active == null || active.write == null || !active.uuid.equals(c.getUuid())) return;
                if (status != BluetoothGatt.GATT_SUCCESS) { fail("Bluetooth write rejected (" + status + "). Open the board setup window and reconnect."); return; }
                complete();
            });
        }
    };
    private void readComplete(BluetoothGatt source, UUID uuid, byte[] data, int status) {
        main.post(() -> {
            if (source != gatt || active == null || active.write != null || !active.uuid.equals(uuid)) return;
            if (status != BluetoothGatt.GATT_SUCCESS) { fail("Bluetooth read rejected (" + status + "). Hold BOOT, reconnect, and enter the displayed PIN."); return; }
            try {
                if (uuid.equals(SETTINGS)) {
                    Settings settings = Settings.decode(data);
                    loaded = true;
                    if (verifying) {
                        if (!Arrays.equals(data, expected)) throw new IllegalArgumentException("Saved settings readback did not match. Reload before retrying.");
                        saving = verifying = false; listener.saveState(false); listener.saved();
                    } else listener.message("Settings loaded from the controller.");
                    listener.settings(settings);
                } else {
                    if (data.length != 20 || data[0] != 1) throw new IllegalArgumentException("Unsupported controller status format.");
                    ByteBuffer b = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN); b.get();
                    Telemetry t = new Telemetry(Byte.toUnsignedInt(b.get()), Byte.toUnsignedInt(b.get()), Byte.toUnsignedInt(b.get()),
                            b.getFloat(), b.getFloat(), b.getFloat(), Short.toUnsignedInt(b.getShort()), Short.toUnsignedInt(b.getShort()));
                    listener.status(t);
                    if (!saving) transaction = t.transaction;
                    if (saving && !verifying && queue.isEmpty() && t.transaction == transaction) {
                        if (t.result == 1) { verifying = true; queue.add(new Op(SETTINGS, null)); }
                        else if (t.result >= 2 && t.result <= 6) {
                            saving = false; listener.saveState(false);
                            String[] errors = {"", "", "Settings rejected by controller validation.",
                                "Setup window closed. Hold BOOT for 2 seconds and retry.", "Flash storage failed; settings were not applied.",
                                "Controller was busy; retry the save.", "Incomplete settings transfer; retry the save."};
                            listener.message(errors[t.result]);
                        }
                    }
                }
            } catch (IllegalArgumentException e) { fail(e.getMessage()); return; }
            complete();
        });
    }
    private void complete() { main.removeCallbacks(timeout); active = null; next(); }
}
