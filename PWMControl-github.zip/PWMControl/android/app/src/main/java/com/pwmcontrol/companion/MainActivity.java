package com.pwmcontrol.companion;

import android.app.*;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public final class MainActivity extends Activity implements BleClient.Listener {
    private static final int BG = Color.rgb(11,18,32), CARD = Color.rgb(20,32,53),
            TEXT = Color.rgb(234,242,255), MUTED = Color.rgb(160,179,198), ACCENT = Color.rgb(85,214,190);
    private BleClient bluetooth;
    private LinearLayout content, pointRows, curveCard, calibrationCard;
    private TextView connectionLabel, messageLabel, temperatureLabel, demandLabel, outputLabel, setupLabel, curveFeedback;
    private Button saveButton, reloadButton, defaultsButton;
    private TextView saveHint, saveMessage;
    private Spinner sensorType;
    private EditText t1, r1, t2, r2, fixed, supply, stop, ramp;
    private CurveView graph;
    private boolean connected, loaded, saving, unlocked, populating;
    private final List<EditText[]> pointFields = new ArrayList<>();
    private final LinkedHashMap<String, BluetoothDevice> devices = new LinkedHashMap<>();
    private ArrayAdapter<String> deviceAdapter;
    private AlertDialog scanDialog;
    private final TextWatcher redraw = new TextWatcher() {
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        public void onTextChanged(CharSequence s, int start, int before, int count) { if (!populating) updateGraph(); }
        public void afterTextChanged(Editable s) {}
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        bluetooth = new BleClient(this, this);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        content = column(); content.setPadding(dp(20), dp(20), dp(20), dp(28)); scroll.addView(content);
        // Android 15 draws edge-to-edge by default. Respect status/navigation bars on all supported versions.
        scroll.setOnApplyWindowInsetsListener((v, insets) -> {
            v.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(),
                    insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom()); return insets;
        });
        setContentView(scroll);
        content.addView(label("PUMP COMPANION", 12, ACCENT));
        TextView title = label("Tune your controller", 28, TEXT); title.setTypeface(null, Typeface.BOLD); content.addView(title);
        content.addView(label("Calibration, temperature curve & live readings", 14, MUTED));

        LinearLayout connection = card();
        connectionLabel = label("Disconnected", 18, TEXT); connection.addView(connectionLabel);
        messageLabel = label("Hold BOOT on the controller for 2 seconds, then connect. Android will ask for the six-digit PIN shown on its screen.", 14, MUTED);
        connection.addView(messageLabel);
        LinearLayout actions = row();
        actions.addView(button("Find controller", this::findController), weight());
        actions.addView(button("Disconnect", () -> bluetooth.disconnect()), weight()); connection.addView(actions);
        setupLabel = label("Bluetooth configuration requires the physical setup window.", 13, MUTED); connection.addView(setupLabel);

        LinearLayout live = card(); live.addView(label("LIVE CONTROLLER", 12, ACCENT));
        LinearLayout readings = row();
        temperatureLabel = metric(readings, "TEMPERATURE", "— °C");
        demandLabel = metric(readings, "DEMAND", "— %"); outputLabel = metric(readings, "OUTPUT", "— %"); live.addView(readings);
        live.addView(label("Duty is a control command; RPM and flow are not measured.", 12, MUTED));

        LinearLayout curve = card(); curveCard = curve; curve.addView(label("Temperature → PWM", 21, TEXT));
        curve.addView(label("Drag the points or edit the values below. The final point stays at 100%. Startup boost, ramping and hysteresis still apply.", 13, MUTED));
        graph = new CurveView(this); curve.addView(graph, new LinearLayout.LayoutParams(-1, dp(210)));
        graph.setOnPointDraggedListener((index, point, stopTemperature) -> {
            if (index >= pointFields.size()) return;
            populating = true;
            try {
                pointFields.get(index)[0].setText(format(point.temperature()));
                pointFields.get(index)[1].setText(format(point.percent()));
                if (index == 0) stop.setText(format(stopTemperature));
            } finally { populating = false; }
            showCurveValidation();
        });
        curveFeedback = label("", 12, MUTED); curveFeedback.setMaxLines(2);
        curveFeedback.setEllipsize(TextUtils.TruncateAt.END);
        curve.addView(curveFeedback, new LinearLayout.LayoutParams(-1, dp(48)));
        LinearLayout headings = row(); headings.addView(label("Temperature °C", 13, MUTED), weight());
        headings.addView(label("PWM duty %", 13, MUTED), weight()); headings.addView(label("", 13, MUTED), new LinearLayout.LayoutParams(dp(46), 1)); curve.addView(headings);
        pointRows = column(); curve.addView(pointRows);
        curve.addView(button("+ Add curve point", this::addPoint));
        curve.addView(label("2–8 points. Temperatures must rise, duty must stay level or rise, and the last point must be 100%. Duty range: 5–100%; temperature range: −20–110 °C. The first point sets minimum running duty.", 12, MUTED));
        LinearLayout behavior = row(); stop = field(behavior, "Stop below °C", "28"); ramp = field(behavior, "Ramp % / second", "10"); curve.addView(behavior);

        LinearLayout calibration = card(); calibrationCard = calibration; calibration.addView(label("Sensor calibration", 21, TEXT));
        sensorType = new Spinner(this);
        ArrayAdapter<String> sensorOptions = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"NTC thermistor · two points", "Linear resistance · two points", "DS18B20 · digital"});
        sensorType.setAdapter(sensorOptions); calibration.addView(sensorType);
        calibration.addView(label("For a resistive sensor, enter two measured temperature/resistance pairs. Digital DS18B20 readings do not use these values.", 13, MUTED));
        LinearLayout first = row(); t1 = field(first, "Point 1 · °C", "25"); r1 = field(first, "Point 1 · Ω", "10000"); calibration.addView(first);
        LinearLayout second = row(); t2 = field(second, "Point 2 · °C", "50"); r2 = field(second, "Point 2 · Ω", "3600"); calibration.addView(second);
        LinearLayout divider = row(); fixed = field(divider, "Fixed resistor · Ω", "10000"); supply = field(divider, "Divider rail · mV", "3300"); calibration.addView(divider);
        calibration.addView(label("Divider wiring: 3V3 → fixed resistor → ADC → sensor → GND. A model cannot correct ADC saturation or incorrect wiring.", 12, MUTED));

        LinearLayout save = card();
        saveButton = button("Save to controller", this::save); save.addView(saveButton);
        saveHint = label("", 13, MUTED); save.addView(saveHint);
        saveMessage = label("", 14, TEXT); save.addView(saveMessage);
        reloadButton = button("Reload controller settings", () -> bluetooth.reload()); save.addView(reloadButton);
        defaultsButton = button("Use example defaults in editor", () -> new AlertDialog.Builder(this)
                .setTitle("Replace editor values?").setMessage("This loads the example values into the form. The controller changes only after you save.")
                .setNegativeButton("Cancel", null).setPositiveButton("Load defaults", (d,w) -> populate(new Settings())).show());
        save.addView(defaultsButton);
        save.addView(label("Save validates and writes settings to controller flash, then reads them back. It can immediately change pump demand. Output enable, signal polarity, PWM frequency, minimum duty, and emergency/fault behavior remain firmware settings.", 12, MUTED));
        populate(new Settings()); updateButtons();
    }

    @Override public void onStart() { super.onStart(); if (bluetooth != null) bluetooth.setPolling(true); }
    @Override public void onStop() { super.onStop(); bluetooth.stopScan(); bluetooth.setPolling(false); }
    @Override public void onDestroy() { bluetooth.close(); super.onDestroy(); }
    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(request, permissions, grants);
        if (request == 10) { if (bluetooth.permissions()) findController(); else message("Allow Nearby devices permission to use Bluetooth. Android 8–11 also needs location permission and Location enabled for scanning."); }
    }
    private void findController() {
        if (saving) { message("Wait for the save to finish before scanning."); return; }
        if (!bluetooth.permissions()) { bluetooth.requestPermissions(); return; }
        devices.clear(); deviceAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        scanDialog = new AlertDialog.Builder(this).setTitle("Choose a pump controller")
                .setAdapter(deviceAdapter, (dialog, which) -> {
                    List<BluetoothDevice> found = new ArrayList<>(devices.values());
                    if (which < found.size()) bluetooth.connect(found.get(which));
                }).setNegativeButton("Cancel", (d,w) -> bluetooth.stopScan()).create();
        scanDialog.setOnCancelListener(d -> bluetooth.stopScan()); scanDialog.show(); bluetooth.scan();
    }
    @SuppressLint("MissingPermission") // Delivered only by a permission-checked BLE scan.
    @Override public void device(BluetoothDevice device, String name) {
        if (!bluetooth.permissions()) return;
        if (devices.containsKey(device.getAddress())) return;
        devices.put(device.getAddress(), device);
        deviceAdapter.add((name == null ? "PWM Pump" : name) + "\n" + device.getAddress());
    }
    @Override public void connection(boolean value) {
        connected = value;
        if (!value) { loaded = false; unlocked = false; temperatureLabel.setText("— °C"); demandLabel.setText("— %"); outputLabel.setText("— %"); graph.setTemperature(null); }
        connectionLabel.setText(value ? "Connected · PWM Pump" : "Disconnected");
        if (!value) setupLabel.setText("Open the board setup window to pair or save settings.");
        updateButtons();
    }
    @Override public void message(String text) {
        messageLabel.setText(text);
        if (saveMessage != null) saveMessage.setText(text);
    }
    @Override public void settings(Settings settings) { loaded = true; populate(settings); updateButtons(); }
    @Override public void saveState(boolean value) {
        saving = value;
        enableChildren(curveCard, !value); enableChildren(calibrationCard, !value);
        updateButtons();
    }
    private void enableChildren(View view, boolean enabled) {
        if (view == null) return;
        view.setEnabled(enabled);
        if (view instanceof ViewGroup group)
            for (int i = 0; i < group.getChildCount(); i++) enableChildren(group.getChildAt(i), enabled);
    }
    @Override public void saved() { message("Saved to controller flash and read back successfully."); }
    @Override public void status(BleClient.Telemetry t) {
        unlocked = t.unlocked();
        temperatureLabel.setText(t.sensorValid() ? String.format(Locale.US, "%.1f °C", t.temperature()) : "FAULT");
        demandLabel.setText(String.format(Locale.US, "%.0f %%", t.demand()));
        outputLabel.setText(String.format(Locale.US, "%.0f %%", t.output()));
        graph.setTemperature(t.sensorValid() ? t.temperature() : null);
        String state = switch(t.state()) { case 0 -> "Off"; case 1 -> "Startup boost"; case 2 -> "Running"; case 3 -> "Sensor fault"; case 4 -> "Overtemperature"; default -> "Unknown state"; };
        connectionLabel.setText("Connected · " + state + (t.demo() ? " · DEMO" : !t.outputEnabled() ? " · output disabled" : !t.pwmReady() ? " · PWM error" : ""));
        setupLabel.setText(unlocked ? "Setup open · " + t.windowSeconds() + " seconds remaining" : "Setup closed · hold BOOT for 2 seconds to save changes");
        setupLabel.setTextColor(unlocked ? ACCENT : MUTED); updateButtons();
        if (unlocked && !saving) saveHint.setText("Setup open · " + t.windowSeconds() + " seconds left to save.");
    }
    private void updateButtons() {
        if (saveButton == null) return;
        saveButton.setEnabled(connected && loaded && unlocked && !saving);
        saveButton.setText(saving ? "Saving & verifying…" : "Save to controller");
        saveHint.setText(saving ? "Sending settings and checking controller readback…" :
                !connected ? "Connect to the controller before saving." :
                !loaded ? "Waiting for controller settings to load…" :
                !unlocked ? "Save locked: hold BOOT on the controller for 2 seconds, then press Save here. Your edits stay in the form." :
                "Setup open. Ready to save your edits.");
        reloadButton.setEnabled(connected && !saving);
        defaultsButton.setEnabled(!saving);
    }
    private void save() {
        try { bluetooth.save(readForm()); }
        catch (IllegalArgumentException e) { new AlertDialog.Builder(this).setTitle("Check settings").setMessage(e.getMessage()).setPositiveButton("OK", null).show(); }
    }
    private Settings readForm() {
        Settings s = new Settings(); s.sensorType = sensorType.getSelectedItemPosition();
        s.t1 = number(t1); s.r1 = number(r1); s.t2 = number(t2); s.r2 = number(r2);
        s.fixedOhms = number(fixed); s.supplyMv = number(supply); s.stop = number(stop); s.ramp = number(ramp);
        s.points.clear(); for (EditText[] fields : pointFields) s.points.add(new Settings.Point(number(fields[0]), number(fields[1])));
        s.validate(); return s;
    }
    private float number(EditText field) {
        try { float value = Float.parseFloat(field.getText().toString().trim().replace(',', '.')); if (!Float.isFinite(value)) throw new NumberFormatException(); return value; }
        catch (NumberFormatException e) { throw new IllegalArgumentException("Enter a finite numeric value in each field."); }
    }
    private void populate(Settings settings) {
        populating = true;
        sensorType.setSelection(settings.sensorType);
        EditText[] fields = {t1, r1, t2, r2, fixed, supply, stop, ramp};
        float[] values = {settings.t1, settings.r1, settings.t2, settings.r2, settings.fixedOhms, settings.supplyMv, settings.stop, settings.ramp};
        for (int i = 0; i < fields.length; i++) fields[i].setText(format(values[i]));
        pointRows.removeAllViews(); pointFields.clear();
        for (Settings.Point point : settings.points) pointRow(point.temperature(), point.percent());
        populating = false; updateGraph();
    }
    private void addPoint() {
        if (pointFields.size() >= 8) { curveFeedback.setText("The controller supports at most eight curve points."); return; }
        try {
            List<Settings.Point> values = readCurvePoints();
            requireCurveGeometry(values);
            int inserted = CurveEditor.insertPoint(values);
            populating = true;
            try {
                pointRows.removeAllViews(); pointFields.clear();
                for (Settings.Point point : values) pointRow(point.temperature(), point.percent());
            } finally { populating = false; }
            updateGraph(); graph.highlightPoint(inserted);
        } catch (IllegalArgumentException e) {
            curveFeedback.setText(e.getMessage()); curveFeedback.setTextColor(Color.rgb(255,204,115));
        }
    }
    private void pointRow(float temperature, float duty) {
        LinearLayout row = row();
        EditText a = numeric(format(temperature)), b = numeric(format(duty)); row.addView(a, weight()); row.addView(b, weight());
        EditText[] pair = {a,b}; pointFields.add(pair);
        Button remove = button("×", () -> {
            if (pointFields.size() <= 2) { message("Keep at least two curve points."); return; }
            pointFields.remove(pair); pointRows.removeView(row); updateGraph();
        });
        remove.setContentDescription("Remove this curve point"); row.addView(remove, new LinearLayout.LayoutParams(dp(46), dp(52)));
        pointRows.addView(row);
    }
    private void updateGraph() {
        if (graph == null || stop == null) return;
        try {
            List<Settings.Point> values = readCurvePoints(); requireCurveGeometry(values);
            float stopTemperature;
            try { stopTemperature = number(stop); }
            catch (IllegalArgumentException e) { stopTemperature = CurveEditor.stopForStartMove(values.get(0).temperature(),2); }
            graph.setCurve(values, stopTemperature); graph.setEditingAllowed(true);
            showCurveValidation();
        } catch (IllegalArgumentException error) {
            graph.setEditingAllowed(false);
            curveFeedback.setText(error.getMessage() + " Graph shows the previous valid points.");
            curveFeedback.setTextColor(Color.rgb(255,204,115));
        }
    }
    private List<Settings.Point> readCurvePoints() {
        List<Settings.Point> values = new ArrayList<>();
        for (EditText[] fields : pointFields) values.add(new Settings.Point(number(fields[0]), number(fields[1])));
        return values;
    }
    private void requireCurveGeometry(List<Settings.Point> values) {
        if (values.size() < 2) throw new IllegalArgumentException("Keep at least two curve points.");
        for (int i = 0; i < values.size(); i++) {
            Settings.Point p = values.get(i);
            if (p.temperature() < Settings.MIN_TEMPERATURE || p.temperature() > Settings.MAX_TEMPERATURE)
                throw new IllegalArgumentException("Curve temperatures must be between -20 and 110 °C.");
            if (p.percent() < Settings.MIN_DUTY || p.percent() > 100)
                throw new IllegalArgumentException("Curve duty must be between 5% and 100%.");
            if (i > 0 && (p.temperature() <= values.get(i-1).temperature() || p.percent() < values.get(i-1).percent()))
                throw new IllegalArgumentException("Temperatures must increase; duty must stay level or rise.");
        }
    }
    private void showCurveValidation() {
        if (curveFeedback == null) return;
        try {
            Settings probe = new Settings(); probe.points.clear(); probe.points.addAll(readCurvePoints()); probe.stop = number(stop);
            probe.validate();
            curveFeedback.setText(pointFields.size() + " control points. Changes apply when you save.");
            curveFeedback.setTextColor(MUTED);
        } catch (IllegalArgumentException error) {
            curveFeedback.setText(error.getMessage()); curveFeedback.setTextColor(Color.rgb(255,204,115));
        }
    }
    private String format(float value) { return value == (int)value ? Integer.toString((int)value) : Float.toString(value); }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout.LayoutParams weight() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1); p.setMargins(0, dp(4), dp(6), dp(4)); return p; }
    private TextView label(String text, int size, int color) { TextView t = new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(color); t.setPadding(0, dp(4), 0, dp(6)); return t; }
    private LinearLayout card() {
        LinearLayout l = column(); l.setPadding(dp(16), dp(14), dp(16), dp(14));
        GradientDrawable background = new GradientDrawable(); background.setColor(CARD); background.setCornerRadius(dp(18)); l.setBackground(background);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.topMargin = dp(16); content.addView(l, p); return l;
    }
    private Button button(String title, Runnable action) {
        Button b = new Button(this); b.setText(title); b.setAllCaps(false); b.setTextSize(13); b.setMinHeight(dp(48));
        b.setBackgroundTintList(new ColorStateList(new int[][]{new int[]{android.R.attr.state_enabled}, new int[]{}}, new int[]{ACCENT, Color.rgb(55,72,89)}));
        b.setTextColor(BG); b.setOnClickListener(v -> action.run()); return b;
    }
    private EditText numeric(String value) {
        EditText e = new EditText(this); e.setSingleLine(true); e.setTextColor(TEXT); e.setTextSize(16);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
        e.setSelectAllOnFocus(true); e.setText(value); e.addTextChangedListener(redraw); return e;
    }
    private EditText field(LinearLayout parent, String title, String value) {
        LinearLayout box = column(); box.addView(label(title, 12, MUTED)); EditText edit = numeric(value); edit.setContentDescription(title); box.addView(edit);
        parent.addView(box, weight()); return edit;
    }
    private TextView metric(LinearLayout parent, String title, String value) {
        LinearLayout box = column(); box.addView(label(title, 10, MUTED)); TextView text = label(value, 22, TEXT); box.addView(text); parent.addView(box, weight()); return text;
    }
    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
