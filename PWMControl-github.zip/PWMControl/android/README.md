# Pump Companion for Android

Native Android BLE app for the firmware in `../PumpController`. Android 8.0 or newer is required. There is no cloud service, account, Internet permission, or background pump-control service.

## Build and install

Open this `android` directory in Android Studio and sync Gradle. Use JDK 17 or newer (21 is also supported by the pinned Gradle 8.11.1), Android SDK 35, and Android Gradle Plugin 8.9.1. Studio can install the required SDK packages. Alternatively:

```powershell
.\gradlew.bat assembleDebug lint
```

The installable debug APK is `app/build/outputs/apk/debug/app-debug.apk`. Transfer it to your phone and allow installation from your chosen file source when Android requests it, or use Android Studio's Run action / `adb install -r` with your own connected phone. The debug APK is for development; produce a signed release build before distributing the app.

`local.properties` is machine-specific and excluded from the source bundle and Git. Android Studio creates it when you select your SDK, or you can create it with `sdk.dir` pointing at your Android SDK. The downloaded `.tools` directory used during local verification is also excluded; a fresh checkout uses your installed SDK. The Gradle wrapper JAR and scripts are from Gradle's official v8.11.1 tag.

## Connect and edit

1. Upload the updated ESP32 firmware. `BLE_ENABLED` defaults to true; pump output is currently enabled in `Config.h`.
2. After the board has booted, hold its **BOOT button for two seconds**. Do not hold BOOT during reset; that enters the ESP32 bootloader. The screen footer displays a six-digit PIN and a two-minute setup countdown.
3. Open Pump Companion, allow **Nearby devices** permission, and tap **Find controller**. Choose `PWM Pump` from the list. On Android 8–11, location permission and the phone's Location switch are needed for BLE scanning; the app does not derive or store location.
4. When Android requests pairing, enter the PIN shown on the board. This prototype uses authenticated, encrypted sessions without persistent BLE bonding; you may be asked to pair again after reconnecting. If Android retains an obsolete bond after a reset, forget that device in Bluetooth settings and reconnect.
5. Settings are read from the controller automatically. Choose NTC, linear resistance, or DS18B20, and enter the calibration and divider values for your hardware. The resistance values are retained but unused when DS18B20 is selected.
6. Drag the numbered graph points or edit the temperature/PWM rows. The first point defines the start temperature. Add intermediate points to shape the curve: a new point is inserted into the widest graph gap and highlighted with its number. Stop temperature defines the lower hysteresis boundary, and ramp controls the rate of ordinary duty changes.
7. With the setup window open, tap **Save to controller**. The app sends the complete settings transaction, waits for firmware validation and flash storage, then reads the saved settings back and compares them. A GATT write acknowledgement alone is not treated as a successful save.

If the countdown expires, hold BOOT again to reopen setup. An authenticated connection can continue showing telemetry after the window closes, but writes are rejected. The window opens only by the physical button; the phone cannot remotely unlock it.

App 0.2.3 shows the setup-window status and all save progress/results directly beneath **Save to controller**, so they remain visible when scrolled to the bottom. If Save is greyed out, check the explanation there: connect and load settings, then hold BOOT for two seconds to reopen the setup window. Holding BOOT while already connected preserves the edits in the form. The matching firmware fixes duplicated BLE write callbacks in Arduino core 3.3.0 that previously caused settings transfers to fail. Both the app and firmware updates were installed on the connected hardware; native callback regression and Java-to-firmware codec/transaction checks passed. A physical phone-to-controller save/readback still requires confirmation.

Closing or disconnecting the app does not stop the controller. Saved settings are loaded at startup. If a connection is lost during a save, its outcome is **unconfirmed**: reconnect and reload the controller before retrying. A save that has already reached flash is not rolled back by a disconnect.

## Editable settings and limits

| Setting | Version 1 limit |
| --- | --- |
| Calibration temperatures | −20–110 °C, separated by at least 0.1 °C |
| Calibration resistances | 1 Ω–10 MΩ, different values |
| NTC model | Resistance must fall as temperature rises |
| Divider fixed resistance | 100 Ω–1 MΩ |
| Divider supply | 3000–3600 mV |
| Curve | 2–8 points, strictly increasing temperatures, nondecreasing duty |
| Curve temperatures | −20–110 °C |
| Curve duty | 5–100%; last point must be 100% |
| Stop temperature | At least −21 °C and below the first curve point |
| Ramp | 0.1–100 percentage points/second |

The default graph uses 30 °C → 35%, 50 °C → 100%, with stop at 28 °C. The graph axes show the entire −20–110 °C sensor range and remain fixed while dragging. Grab a point to move it; the readout shows its temperature/duty and the numeric row updates immediately. Touch targets extend beyond the visible dots. Dragging snaps to 0.1 °C and 1% duty, keeps temperatures at least 0.1 °C apart, preserves nondecreasing duty, and keeps the last point at 100%. Moving the first point also moves stop temperature to preserve its existing hysteresis gap, limited by the −21 °C minimum stop threshold. You can therefore drag the first point down to −20 °C without manually lowering stop first. Use the numeric fields for finer or tightly spaced points. Dragging changes the editor only; press Save to apply it to the pump.

The surrounding page scrolls when you swipe away from a point. Graph editing is disabled during a save. Invalid point coordinates keep the previous drawable curve with an inline explanation. A stop-setting or final-duty error no longer hides newly added points: the graph shows the current coordinates with a validation message, and Save still requires valid settings. A stop threshold below −20 °C allows the first curve point to be placed at −20 °C, and means no normal stop is requested within the valid sensor range.

Between points, the firmware interpolates linearly. Below the first point, an already running pump holds that first duty until stop temperature is reached. The preview shows the rising-temperature target; it does not simulate startup boost, time-based ramping, the falling-temperature hysteresis branch, or fault overrides. Saving validates every field.

App 0.2 and the matching firmware allow curve points through 110 °C. The firmware's immediate full-output override is now 110 °C, replacing the original 60 °C example setting. Readings outside −20–110 °C still invoke the configured sensor-fault response. Update both the app and ESP32 firmware to use the expanded range; older firmware will reject curve temperatures above 60 °C. The unchanged example curve still reaches a 100% target at 50 °C until you edit it.

**Save applies settings immediately** and briefly invalidates the old sensor reading before resampling with the new calibration. The configured sensor-fault policy therefore applies during that transition. The source default is 100% demand for a cooling application. When output is enabled, edit settings with that behavior in mind.

PWM output enable, GPIO pins, frequency, inversion, minimum running duty, emergency threshold, sensor valid range, startup boost, and sensor-fault duty remain source settings. The app cannot bypass output disable or emergency/fault handling. App v1 validation matches the supplied firmware defaults; update both validators if you change the firmware's minimum duty or temperature limits.

The **Use example defaults in editor** button only fills the form. It changes the board after a successful save. Calibration examples are not measured values for your sensor.

App 0.2.2 and the matching firmware allow running duty down to 5%. Set the first curve point to 5% to use that minimum; the example still starts at 35% until edited. The normal stop command remains 0%. Older firmware with the original 35% floor will reject a saved curve containing a lower duty, so update both components.

## Source layout

- `Settings.java`: portable validation, little-endian settings codec, CRC32 and transaction frames.
- `BleClient.java`: filtered scan, Android permissions, serialized GATT operations, timeouts, telemetry polling, save acknowledgement and readback.
- `MainActivity.java`: connection, calibration and curve editing screens.
- `CurveView.java`: draggable target-curve graph, touch feedback, scroll handling, and live temperature marker.
- `CurveEditor.java`: portable dragging constraints and snapping.
- [BLE protocol](../docs/ble-protocol.md): firmware/app packet contract.

The app deliberately polls a 20-byte status value about once per second, avoiding notification/CCCD setup. Settings writes are at most 20 bytes each and work with the default ATT MTU. Settings reads use a standard long characteristic read.

## Verification

Portable C++ tests cover runtime settings validation, curve interpolation, ramp/fault behavior and transaction handling. A Java test compares the app's encoded settings against a C++-generated fixture; C++ then consumes a full Java-generated settings transaction. Physical phone-to-board pairing, flash persistence across a real power cycle, and actual pump behavior require bench testing.

The debug APK was built and opened in an API 37 emulator. The calibration layout, adding an interpolated curve point, disabled disconnected save controls, and Nearby devices permission prompt were checked. Portable Java tests cover drag snapping, neighboring-point constraints, the stop threshold, the fixed 100% endpoint, and the full −20–110 °C range. Android lint previously could not complete because Google's lint artifact downloads returned HTTP 503 / connection reset errors; it has not been marked as passed.

The updated live preview was also checked with six numbered graph handles and a 5% first point. The start point was observed below 28.1 °C, with the stop field following its hysteresis gap. Firmware tests confirm a 5% curve produces 5% running demand and still stops at 0%.

The local APK build used the installed SDK's `aapt2` through Gradle's `-Pandroid.aapt2FromMavenOverride=...` option when Google's matching resource-compiler download failed. Java was configured to use Windows' trusted certificate store on this network. These are local build-environment workarounds, not app runtime requirements.

Official references: [Android BLE permissions](https://developer.android.com/develop/connectivity/bluetooth/bt-permissions), [Android GATT API](https://developer.android.com/reference/android/bluetooth/BluetoothGatt), [ESP32-C6 BLE overview](https://docs.espressif.com/projects/esp-idf/en/latest/esp32c6/api-guides/ble/overview.html).

Test sources and Android images/screenshots are omitted from this source archive. Build the APK from the included app source using the instructions above.
