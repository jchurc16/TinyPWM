"""Print an NTC Beta or linear two-point resistance/temperature map. No dependencies."""
import argparse
import math


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--point1", nargs=2, type=float, required=True, metavar=("CELSIUS", "OHMS"))
    parser.add_argument("--point2", nargs=2, type=float, required=True, metavar=("CELSIUS", "OHMS"))
    parser.add_argument("--linear", action="store_true", help="Use linear resistance interpolation instead of NTC Beta")
    parser.add_argument("--temperatures", nargs="+", type=float, default=[20, 25, 30, 35, 40, 45, 50, 60])
    parser.add_argument("--fixed-ohms", type=float, default=10000)
    parser.add_argument("--supply-mv", type=float, default=3300)
    args = parser.parse_args()
    t1, r1 = args.point1
    t2, r2 = args.point2
    values = [t1, r1, t2, r2, args.fixed_ohms, args.supply_mv, *args.temperatures]
    if not all(math.isfinite(v) for v in values):
        parser.error("All inputs must be finite")
    if min(r1, r2, args.fixed_ohms, args.supply_mv) <= 0 or min(t1, t2, *args.temperatures) <= -273.15:
        parser.error("Resistances/supply must be positive; temperatures must exceed absolute zero")
    if t1 == t2 or r1 == r2:
        parser.error("Calibration temperatures and resistances must differ")
    beta = math.log(r1 / r2) / (1 / (t1 + 273.15) - 1 / (t2 + 273.15))
    if not args.linear and beta <= 0:
        parser.error("For NTC mode, resistance must decrease as temperature increases")
    print("Linear model" if args.linear else f"NTC Beta = {beta:.2f} K")
    print("EXAMPLE/ESTIMATED MAP: replace firmware calibration values with your measured pairs.")
    print(f"{'Temp C':>8} {'Resistance ohm':>16} {'ADC mV':>10}  Notes")
    for temp in args.temperatures:
        try:
            resistance = (r1 + (temp - t1) * (r2 - r1) / (t2 - t1) if args.linear else
                          r1 * math.exp(beta * (1 / (temp + 273.15) - 1 / (t1 + 273.15))))
        except OverflowError:
            parser.error("Requested range exceeds this model's numeric range")
        if resistance <= 0:
            print(f"{temp:8.2f} {'invalid':>16} {'--':>10}  Model predicts nonpositive resistance")
            continue
        mv = args.supply_mv * resistance / (args.fixed_ohms + resistance)
        notes = []
        if not min(t1, t2) <= temp <= max(t1, t2):
            notes.append("extrapolated")
        if not 50 <= mv <= 2450:
            notes.append("outside configured C6 ADC window")
        print(f"{temp:8.2f} {resistance:16.2f} {mv:10.2f}  {', '.join(notes)}")


if __name__ == "__main__":
    main()
