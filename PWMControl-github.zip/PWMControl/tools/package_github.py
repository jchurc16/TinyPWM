"""Create a small GitHub source archive without tests, Android images or tools/caches."""
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "dist" / "PWMControl-github.zip"
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".avif", ".ico", ".svg", ".img", ".qcow2"}
EXCLUDED_DIRS = {"tests", "test", "androidtest", "build", ".gradle", ".idea", ".kotlin", ".cxx", ".externalnativebuild", "__pycache__"}


def include(path):
    rel = path.relative_to(ROOT)
    parts = tuple(p.lower() for p in rel.parts)
    if any(p in EXCLUDED_DIRS for p in parts[:-1]):
        return False
    if "android" == parts[0] and path.suffix.lower() in IMAGE_EXTENSIONS:
        return False
    return not (path.name == "local.properties" or path.suffix.lower() in {".apk", ".aab", ".keystore", ".jks", ".iml", ".pyc"})


def packaged_text(rel, text):
    if rel == "README.md":
        text = text.replace("firmware, Android app source, documentation, portable tests, and the calibration helper",
                            "firmware, Android app source, documentation, and the calibration helper")
        text = re.sub(r"^- `tests/.*\n", "", text, flags=re.MULTILINE)
        text = re.sub(r"Run portable tests using a C\+\+11-or-newer host compiler:.*?(?=## Hardware and API references)", "", text, flags=re.DOTALL)
        text += "\n## Source archive\n\nThis GitHub package excludes all test sources, Android images/screenshots, generated APKs and firmware binaries, SDKs, caches, signing keys, local settings, and Git history. Wiring diagrams in `docs/` are included. Historical verification notes describe checks performed in the development workspace; test programs are not included in this archive.\n\nExtract the ZIP and upload the contents of `PWMControl/`, including `.gitignore` and `.gitattributes`, to the GitHub repository. Recreate this archive with `python tools/package_github.py`.\n"
    elif rel == "android/README.md":
        text = re.sub(r"From the repository root, with a host C\+\+ compiler and JDK available:.*?(?=Official references:)", "", text, flags=re.DOTALL)
        text += "\nTest sources and Android images/screenshots are omitted from this source archive. Build the APK from the included app source using the instructions above.\n"
    elif rel == ".gitignore":
        text += "\n# Excluded from this GitHub source package\ntests/\nandroid/**/src/test/\nandroid/**/src/androidTest/\n"
    return text


def main():
    files = [ROOT / p for p in (".gitignore", ".gitattributes", "README.md", "arduino-cli.yaml",
                                "tools/calibration_map.py", "tools/package_github.py")]
    for folder in ("PumpController", "docs"):
        files.extend(p for p in (ROOT / folder).rglob("*") if p.is_file() and include(p))
    for filename in ("README.md", "build.gradle", "settings.gradle", "gradle.properties", "gradlew", "gradlew.bat", "app/build.gradle"):
        files.append(ROOT / "android" / filename)
    for folder in ("android/gradle/wrapper", "android/app/src"):
        files.extend(p for p in (ROOT / folder).rglob("*") if p.is_file() and include(p))
    files = sorted(set(files))
    for path in files:
        if not path.resolve().is_relative_to(ROOT) or not include(path):
            raise ValueError(f"Unexpected package input: {path}")
    OUTPUT.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(OUTPUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            rel = path.relative_to(ROOT).as_posix()
            data = path.read_bytes()
            if rel in {"README.md", "android/README.md", ".gitignore"}:
                data = packaged_text(rel, data.decode("utf-8")).encode("utf-8")
            info = zipfile.ZipInfo.from_file(path, "PWMControl/" + rel)
            info.compress_type = zipfile.ZIP_DEFLATED
            if rel == "android/gradlew":
                info.external_attr = 0o100755 << 16
            archive.writestr(info, data)
    with zipfile.ZipFile(OUTPUT) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("Archive CRC verification failed")
        names = archive.namelist()
        assert len(names) == len(set(names))
        for path in names:
            rel = Path(path).relative_to("PWMControl")
            assert include(ROOT / rel), path
            assert not any(p.lower() in EXCLUDED_DIRS for p in rel.parts[:-1]), path
        for required in ("PumpController/PumpController.ino", "PumpController/src/waveshare_c3/LICENSE",
                         "android/app/src/main/java/com/pwmcontrol/companion/MainActivity.java",
                         "android/gradle/wrapper/gradle-wrapper.jar", ".gitignore", ".gitattributes"):
            assert "PWMControl/" + required in names, required
    print(f"Created {OUTPUT}")
    print(f"{len(files)} files; {OUTPUT.stat().st_size:,} bytes ({OUTPUT.stat().st_size / 1024:.1f} KiB)")
    print("Verified: readable archive; required firmware/app sources and wrapper included; tests, Android images, build outputs and local files excluded.")


if __name__ == "__main__":
    main()
