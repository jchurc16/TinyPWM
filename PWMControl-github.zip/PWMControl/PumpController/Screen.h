#pragma once
#include <Arduino_GFX_Library.h>
#include <cstring>
#include "Config.h"
#include "PumpLogic.h"
#include "PumpOutput.h"
#include "TemperatureSensor.h"
#if defined(CONFIG_IDF_TARGET_ESP32C3)
#include "src/waveshare_c3/ESP32_C3_LCD_1in47.h"
#endif

class Screen {
 public:
#if defined(CONFIG_IDF_TARGET_ESP32C3)
  Screen() : panel_(4) {} // Portrait with the C3 panel's reflected scan direction.
#else
  Screen() : bus_(15, 14, 7, 6, GFX_NOT_DEFINED),
      panel_(&bus_, 21, 0, true, 172, 320, 34, 0, 34, 0) {}
#endif
  void begin() {
#if defined(CONFIG_IDF_TARGET_ESP32C3)
    ready_ = panel_.begin(Config::BACKLIGHT_PERCENT, 40000000);
    display_ = panel_.gfx();
#else
    // Disable shared SD card while using the display SPI bus.
    pinMode(4, OUTPUT);
    digitalWrite(4, HIGH);
    ready_ = panel_.begin(40000000);
    display_ = &panel_;
#endif
    if (!ready_) { Serial.println("Display init failed; control continues"); return; }
    // Apply portrait rotation after the manufacturer's init overwrites MADCTL.
    // The C3 panel needs reflected addressing to show text the right way round.
#if defined(CONFIG_IDF_TARGET_ESP32C3)
    display_->setRotation(4);
#else
    display_->setRotation(0);
#endif
    display_->fillScreen(0x0000);
    display_->setTextWrap(false);
    centered(14, "WATER PUMP", 2, Accent);
    display_->drawFastHLine(12, 42, display_->width() - 24, Divider);
    centered(56, "TEMPERATURE", 1, Muted);
    display_->drawFastHLine(12, 152, display_->width() - 24, Divider);
    centered(170, "PWM OUTPUT", 1, Muted);
#if !defined(CONFIG_IDF_TARGET_ESP32C3)
    if (ledcAttach(22, 5000, 8)) ledcWrite(22, Config::BACKLIGHT_PERCENT * 255 / 100);
#endif
  }
  void update(uint32_t now, const TemperatureSensor& sensor, const PumpLogic& pump, const PumpOutput& output,
              bool setupOpen = false, uint32_t pin = 0, uint16_t setupSeconds = 0) {
    if (!ready_ || (drawn_ && now - lastDraw_ < Config::DISPLAY_REFRESH_MS)) return;
    drawn_ = true;
    lastDraw_ = now;
    // Update only changed regions so the large values do not blink every loop.
    char text[32];
    const bool sensorValid = sensor.valid(now);
    if (sensorValid) snprintf(text, sizeof(text), "%.1f", sensor.temperature());
    else snprintf(text, sizeof(text), "FAULT");
    if (changed(lastTemperature_, text)) {
      clearBand(74, 68);
      if (sensorValid) {
        centered(82, text, 4, White);
        centered(128, "CELSIUS", 1, Muted);
      } else {
        // Replace the entire temperature value/unit with a red warning icon.
        const int16_t cx = display_->width() / 2;
        display_->fillTriangle(cx, 78, cx - 29, 132, cx + 29, 132, Red);
        display_->fillRect(cx - 3, 95, 6, 19, Black);
        display_->fillCircle(cx, 123, 3, Black);
      }
    }
    snprintf(text, sizeof(text), "%.0f%%", output.applied());
    if (changed(lastOutput_, text)) {
      clearBand(190, 48);
      centered(194, text, 5, Accent);
    }

    const bool outputError = PumpOutput::enabled() && !output.ready();
    const char* status = outputError ? "PWM ERROR" :
        Config::DEMO_MODE ? "DEMO MODE" :
        !PumpOutput::enabled() ? "OUTPUT DISABLED" :
        !sensorValid ? "SENSOR FAULT" : pump.stateName();
    if (changed(lastStatus_, status)) {
      clearBand(250, 20);
      const bool fault = outputError || strcmp(status, "SENSOR FAULT") == 0 ||
          strcmp(status, "OVER TEMP") == 0;
      centered(252, status, 1, fault ? Red : Muted);
    }

    if (setupOpen) snprintf(text, sizeof(text), "%06lu", static_cast<unsigned long>(pin));
    else snprintf(text, sizeof(text), "HOLD BOOT FOR SETUP");
    if (changed(lastSetup_, text)) {
      clearBand(278, 18);
      centered(280, text, setupOpen ? 2 : 1, setupOpen ? Accent : Muted);
    }
    if (setupOpen) snprintf(text, sizeof(text), "BLUETOOTH  %us", setupSeconds);
    else text[0] = '\0';
    if (changed(lastCountdown_, text)) {
      clearBand(302, 12);
      centered(304, text, 1, Muted);
    }
  }
 private:
  static constexpr uint16_t Black = 0x0000, White = 0xFFFF, Red = 0xF800;
  static constexpr uint16_t Accent = 0x07FF, Muted = 0x9CF3, Divider = 0x2945;

  template <size_t N>
  static bool changed(char (&previous)[N], const char* next) {
    if (strcmp(previous, next) == 0) return false;
    snprintf(previous, N, "%s", next);
    return true;
  }
  void clearBand(int16_t y, int16_t height) {
    display_->fillRect(0, y, display_->width(), height, Black);
  }
  void centered(int16_t y, const char* text, uint8_t size, uint16_t color) {
    // Default GFX font uses a 6x8 cell. Size 4 fits -20.0 through 110.0.
    const int16_t width = static_cast<int16_t>(strlen(text)) * 6 * size;
    display_->setCursor((display_->width() - width) / 2, y);
    display_->setTextSize(size);
    display_->setTextColor(color);
    display_->print(text);
  }
#if defined(CONFIG_IDF_TARGET_ESP32C3)
  ESP32_C3_LCD_1in47 panel_;
#else
  // Standard Arduino hardware SPI supports the C6 with the pinned GFX version.
  Arduino_HWSPI bus_;
  Arduino_ST7789 panel_;
#endif
  Arduino_GFX* display_ = nullptr;
  bool ready_ = false, drawn_ = false;
  uint32_t lastDraw_ = 0;
  char lastTemperature_[12] = {}, lastOutput_[12] = {}, lastStatus_[24] = {};
  char lastSetup_[32] = {}, lastCountdown_[32] = {};
};
