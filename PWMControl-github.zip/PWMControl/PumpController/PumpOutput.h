#pragma once
#include <Arduino.h>
#include "Config.h"

class PumpOutput {
 public:
  bool begin() {
    pinMode(Config::PWM_PIN, OUTPUT);
    digitalWrite(Config::PWM_PIN, Config::INVERT_GPIO ? HIGH : LOW);
    if (!enabled()) return true;
    ready_ = ledcAttach(Config::PWM_PIN, Config::PWM_FREQUENCY_HZ, Config::PWM_BITS);
    if (ready_) write(0);
    return ready_;
  }
  void write(float percent) {
    applied_ = ready_ && enabled() ? constrain(percent, 0.0f, 100.0f) : 0;
    if (!ready_) return;
    const uint32_t maximum = (1UL << Config::PWM_BITS) - 1;
    uint32_t duty = lroundf(applied_ * maximum / 100.0f);
    if (Config::INVERT_GPIO) duty = maximum - duty;
    if (!ledcWrite(Config::PWM_PIN, duty)) {
      ready_ = false;
      applied_ = 0;
      ledcDetach(Config::PWM_PIN);
      pinMode(Config::PWM_PIN, OUTPUT);
      digitalWrite(Config::PWM_PIN, Config::INVERT_GPIO ? HIGH : LOW);
    }
  }
  static bool enabled() { return Config::OUTPUT_ENABLED && !Config::DEMO_MODE; }
  bool ready() const { return ready_; }
  float applied() const { return applied_; } // Command only; no speed/flow feedback.
 private:
  bool ready_ = false;
  float applied_ = 0;
};
