#pragma once
#include <math.h>
#include <stdint.h>
#include "Config.h"
#include "ControllerSettings.h"

class PumpLogic {
 public:
  enum class State { Off, Starting, Running, SensorFault, Overtemperature };
  void setSettings(const ControllerSettings& settings) {
    settings_ = settings;
    initialized_ = running_ = boost_ = false;
    target_ = output_ = 0;
    state_ = State::Off;
  }
  const ControllerSettings& settings() const { return settings_; }

  void update(float temperatureC, bool sensorValid, uint32_t now) {
    const uint32_t elapsed = initialized_ ? now - lastUpdate_ : 0;
    initialized_ = true;
    lastUpdate_ = now;
    if (!sensorValid || !isfinite(temperatureC)) {
      state_ = State::SensorFault;
      target_ = output_ = Config::SENSOR_FAULT_PERCENT;
      boost_ = false;
      running_ = output_ > 0;
      return;
    }
    if (temperatureC >= Config::EMERGENCY_TEMP_C) {
      state_ = State::Overtemperature;
      target_ = output_ = 100;
      boost_ = false;
      running_ = true;
      return;
    }

    if (temperatureC <= settings_.stopTemperature) {
      running_ = false;
      boost_ = false;
      target_ = output_ = 0; // Stop immediately; never linger below usable duty.
      state_ = State::Off;
      return;
    }
    if (!running_ && temperatureC >= settings_.points[0].temperature) {
      running_ = true;
      boost_ = Config::START_BOOST_MS > 0;
      boostStart_ = now;
      output_ = boost_ ? 100 : settings_.points[0].percent;
    }
    if (!running_) {
      target_ = output_ = 0;
      state_ = State::Off;
      return;
    }

    target_ = settings_.targetAt(temperatureC);
    if (boost_ && now - boostStart_ < Config::START_BOOST_MS) {
      output_ = 100;
      state_ = State::Starting;
      return;
    }
    if (boost_) {
      boost_ = false;
      output_ = target_; // End boost at requested speed, avoiding a long 100% tail.
    } else {
      // Limit delayed-loop catch-up, including after a slow screen operation.
      const uint32_t stepMs = elapsed > 250 ? 250 : elapsed;
      const float step = settings_.rampRate * stepMs / 1000.0f;
      output_ += fmaxf(-step, fminf(step, target_ - output_));
    }
    output_ = fmaxf(Config::MIN_RUNNING_PERCENT, fminf(100, output_));
    state_ = State::Running;
  }

  float output() const { return output_; }
  float target() const { return target_; }
  State state() const { return state_; }
  const char* stateName() const {
    switch (state_) {
      case State::Off: return "OFF";
      case State::Starting: return "START BOOST";
      case State::Running: return "RUNNING";
      case State::SensorFault: return "SENSOR FAULT";
      case State::Overtemperature: return "OVER TEMP";
    }
    return "UNKNOWN";
  }

 private:
  ControllerSettings settings_;
  bool initialized_ = false, running_ = false, boost_ = false;
  uint32_t lastUpdate_ = 0, boostStart_ = 0;
  float target_ = 0, output_ = 0;
  State state_ = State::Off;
};
