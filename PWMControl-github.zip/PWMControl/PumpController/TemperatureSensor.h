#pragma once
#include <Arduino.h>
#include <DallasTemperature.h>
#include <OneWire.h>
#include "Config.h"
#include "ResistanceCalibration.h"
#include "ControllerSettings.h"

class TemperatureSensor {
 public:
  TemperatureSensor() : oneWire_(Config::ONE_WIRE_PIN), digital_(&oneWire_),
      calibration_(Config::CAL_TEMP_1_C, Config::CAL_RESISTANCE_1_OHM,
                   Config::CAL_TEMP_2_C, Config::CAL_RESISTANCE_2_OHM) {}

  void begin() {
    if (Config::DEMO_MODE) return;
    if (settings_.sensorType == Config::SensorType::DS18B20) {
      digital_.begin();
      digital_.setWaitForConversion(false);
    } else {
      analogReadResolution(12);
      analogSetPinAttenuation(Config::ANALOG_SENSOR_PIN, ADC_11db);
    }
  }

  void setSettings(const ControllerSettings& settings) {
    settings_ = settings;
    calibration_ = ResistanceCalibration(settings.t1, settings.r1, settings.t2, settings.r2);
    sampled_ = converting_ = valid_ = false;
    temperature_ = resistance_ = voltageMv_ = NAN;
    begin();
  }

  void update(uint32_t now) {
    if (Config::DEMO_MODE) {
      // 20 -> 65 -> 20 C over 90 seconds, exercising the default pump curve.
      const float seconds = (now % 90000) / 1000.0f;
      accept(20 + (seconds < 45 ? seconds : 90 - seconds), now);
      return;
    }
    if (settings_.sensorType == Config::SensorType::DS18B20) {
      if (converting_) {
        if (now - conversionStart_ < 750) return;
        converting_ = false;
        const float value = digital_.getTempC(address_);
        // Conservatively reject the DS18B20 power-on value, including genuine 85 C.
        accept(value == 85.0f ? NAN : value, now);
        return;
      }
      if (sampled_ && now - lastRequest_ < Config::SENSOR_SAMPLE_MS) return;
      sampled_ = true;
      lastRequest_ = now;
      // Raw search avoids DallasTemperature's cached startup device count, so
      // a probe absent at boot can subsequently be discovered.
      oneWire_.reset_search();
      bool found = false;
      while (oneWire_.search(address_)) {
        if (address_[0] == 0x28 && digital_.validAddress(address_)) {
          found = true;
          break;
        }
      }
      if (!found) {
        accept(NAN, now);
        return;
      }
      if (!digital_.requestTemperaturesByAddress(address_)) {
        accept(NAN, now);
        return;
      }
      conversionStart_ = now;
      converting_ = true;
      return;
    }
    if (sampled_ && now - lastRequest_ < Config::SENSOR_SAMPLE_MS) return;
    sampled_ = true;
    lastRequest_ = now;
    uint32_t totalMv = 0;
    bool atRail = false;
    for (int i = 0; i < 16; ++i) {
      // Check raw saturation too: calibrated millivolts at full scale can vary
      // between chips, so the millivolt window alone cannot detect every open.
      const uint16_t raw = analogRead(Config::ANALOG_SENSOR_PIN);
      atRail |= raw <= 5 || raw >= 4090;
      totalMv += analogReadMilliVolts(Config::ANALOG_SENSOR_PIN);
    }
    voltageMv_ = totalMv / 16.0f;
    if (atRail || voltageMv_ < Config::ADC_MIN_MV || voltageMv_ > Config::ADC_MAX_MV) {
      resistance_ = NAN;
      accept(NAN, now);
      return;
    }
    resistance_ = ResistanceCalibration::resistanceFromDivider(
        voltageMv_, settings_.supplyMv, settings_.fixedOhms);
    accept(calibration_.temperature(resistance_, settings_.sensorType == Config::SensorType::NtcTwoPoint), now);
  }

  bool valid(uint32_t now) const { return valid_ && now - lastGood_ <= Config::SENSOR_STALE_MS; }
  float temperature() const { return temperature_; }
  float resistance() const { return resistance_; }
  float voltageMv() const { return voltageMv_; }

 private:
  ControllerSettings settings_;
  void accept(float value, uint32_t now) {
    valid_ = isfinite(value) && value >= Config::SENSOR_MIN_C && value <= Config::SENSOR_MAX_C;
    temperature_ = valid_ ? value : NAN;
    if (valid_) lastGood_ = now;
  }
  OneWire oneWire_;
  DallasTemperature digital_;
  DeviceAddress address_ = {};
  ResistanceCalibration calibration_;
  bool sampled_ = false, converting_ = false, valid_ = false;
  uint32_t lastRequest_ = 0, conversionStart_ = 0, lastGood_ = 0;
  float temperature_ = NAN, resistance_ = NAN, voltageMv_ = NAN;
};
