#pragma once
#include <math.h>
#include <stdint.h>
#include <string.h>
#include "Config.h"
#include "ResistanceCalibration.h"

struct CurvePoint { float temperature; float percent; };

struct ControllerSettings {
  static constexpr uint8_t MAX_POINTS = 8;
  Config::SensorType sensorType = Config::SENSOR_TYPE;
  uint8_t pointCount = 2;
  float t1 = Config::CAL_TEMP_1_C, r1 = Config::CAL_RESISTANCE_1_OHM;
  float t2 = Config::CAL_TEMP_2_C, r2 = Config::CAL_RESISTANCE_2_OHM;
  float fixedOhms = Config::FIXED_RESISTOR_OHM, supplyMv = Config::DIVIDER_SUPPLY_MV;
  float stopTemperature = Config::STOP_TEMP_C;
  float rampRate = Config::RAMP_PERCENT_PER_SECOND;
  CurvePoint points[MAX_POINTS] = {};

  ControllerSettings() {
    points[0] = {Config::START_TEMP_C, Config::DEFAULT_START_PERCENT};
    points[1] = {Config::FULL_SPEED_TEMP_C, 100};
  }

  const char* validationError() const {
    if (static_cast<uint8_t>(sensorType) > 2) return "Unknown sensor type";
    if (pointCount < 2 || pointCount > MAX_POINTS) return "Use 2 to 8 curve points";
    if (!isfinite(t1) || !isfinite(t2) || t1 < Config::SENSOR_MIN_C || t2 < Config::SENSOR_MIN_C ||
        t1 > Config::SENSOR_MAX_C || t2 > Config::SENSOR_MAX_C) return "Calibration temperature out of range";
    if (!isfinite(r1) || !isfinite(r2) || r1 < 1 || r2 < 1 || r1 > 1e7f || r2 > 1e7f)
      return "Calibration resistance out of range";
    if (fabsf(t2 - t1) < 0.1f) return "Calibration temperatures must differ by at least 0.1 C";
    if (!ResistanceCalibration(t1, r1, t2, r2).valid(sensorType == Config::SensorType::NtcTwoPoint))
      return "Invalid two-point calibration";
    if (!isfinite(fixedOhms) || fixedOhms < 100 || fixedOhms > 1e6f) return "Invalid fixed resistor";
    if (!isfinite(supplyMv) || supplyMv < 3000 || supplyMv > 3600) return "Invalid divider supply";
    if (!isfinite(stopTemperature) || stopTemperature < Config::SENSOR_MIN_C - 1.0f ||
        stopTemperature >= points[0].temperature) return "Stop must be below first curve temperature";
    if (!isfinite(rampRate) || rampRate < 0.1f || rampRate > 100) return "Ramp must be 0.1 to 100 percent/s";
    for (uint8_t i = 0; i < pointCount; ++i) {
      const CurvePoint& p = points[i];
      if (!isfinite(p.temperature) || p.temperature < Config::SENSOR_MIN_C ||
          p.temperature > Config::EMERGENCY_TEMP_C) return "Curve temperature out of range";
      if (!isfinite(p.percent) || p.percent < Config::MIN_RUNNING_PERCENT || p.percent > 100)
        return "Curve duty below minimum or above 100";
      if (i && (p.temperature <= points[i - 1].temperature || p.percent < points[i - 1].percent))
        return "Curve temperatures must increase and duty must not decrease";
    }
    if (points[pointCount - 1].percent != 100) return "Last curve point must be 100 percent";
    return nullptr;
  }

  float targetAt(float temperature) const {
    if (temperature <= points[0].temperature) return points[0].percent;
    for (uint8_t i = 1; i < pointCount; ++i) {
      if (temperature <= points[i].temperature) {
        const CurvePoint& a = points[i - 1];
        const CurvePoint& b = points[i];
        return a.percent + (temperature - a.temperature) * (b.percent - a.percent) /
                           (b.temperature - a.temperature);
      }
    }
    return points[pointCount - 1].percent;
  }
};

namespace SettingsWire {
static_assert(sizeof(float) == 4, "BLE settings require 32-bit floats");
constexpr size_t SIZE = 100;
inline uint16_t read16(const uint8_t* p) { return uint16_t(p[0]) | uint16_t(p[1]) << 8; }
inline uint32_t read32(const uint8_t* p) {
  return uint32_t(p[0]) | uint32_t(p[1]) << 8 | uint32_t(p[2]) << 16 | uint32_t(p[3]) << 24;
}
inline void write16(uint8_t* p, uint16_t v) { p[0] = v; p[1] = v >> 8; }
inline void write32(uint8_t* p, uint32_t v) { for (uint8_t i = 0; i < 4; ++i) p[i] = v >> (8 * i); }
inline float readFloat(const uint8_t* p) { uint32_t bits = read32(p); float v; memcpy(&v, &bits, 4); return v; }
inline void writeFloat(uint8_t* p, float v) { uint32_t bits; memcpy(&bits, &v, 4); write32(p, bits); }
inline uint32_t crc32(const uint8_t* p, size_t length) {
  uint32_t crc = 0xffffffff;
  for (size_t i = 0; i < length; ++i) {
    crc ^= p[i];
    for (uint8_t bit = 0; bit < 8; ++bit) crc = (crc >> 1) ^ (0xedb88320u & (0u - (crc & 1u)));
  }
  return ~crc;
}
inline void encode(const ControllerSettings& s, uint8_t* out) {
  memset(out, 0, SIZE);
  out[0] = 1; out[1] = static_cast<uint8_t>(s.sensorType); out[2] = s.pointCount;
  const float fields[] = {s.t1, s.r1, s.t2, s.r2, s.fixedOhms, s.supplyMv, s.stopTemperature, s.rampRate};
  for (size_t i = 0; i < 8; ++i) writeFloat(out + 4 + 4 * i, fields[i]);
  for (uint8_t i = 0; i < s.pointCount; ++i) {
    writeFloat(out + 36 + 8 * i, s.points[i].temperature);
    writeFloat(out + 40 + 8 * i, s.points[i].percent);
  }
}
inline bool decode(const uint8_t* bytes, size_t length, ControllerSettings& out) {
  if (length != SIZE || bytes[0] != 1 || bytes[3] != 0 || bytes[2] < 2 || bytes[2] > 8) return false;
  ControllerSettings candidate;
  candidate.sensorType = static_cast<Config::SensorType>(bytes[1]); candidate.pointCount = bytes[2];
  float* fields[] = {&candidate.t1, &candidate.r1, &candidate.t2, &candidate.r2,
                    &candidate.fixedOhms, &candidate.supplyMv, &candidate.stopTemperature, &candidate.rampRate};
  for (size_t i = 0; i < 8; ++i) *fields[i] = readFloat(bytes + 4 + 4 * i);
  for (uint8_t i = 0; i < candidate.pointCount; ++i)
    candidate.points[i] = {readFloat(bytes + 36 + 8 * i), readFloat(bytes + 40 + 8 * i)};
  if (candidate.validationError()) return false;
  out = candidate;
  return true;
}
}

// Transactions fit even the default BLE ATT MTU (20-byte writes). No heap use.
class SettingsTransfer {
 public:
  enum Result : uint8_t { None = 0, Saved = 1, Invalid = 2, Locked = 3, StorageError = 4,
                         Busy = 5, BadTransfer = 6, Staging = 7 };
  Result receive(const uint8_t* frame, size_t size, bool unlocked, uint32_t now) {
    if (!unlocked) { reset(); return Locked; }
    if (size < 3 || size > 20) { reset(); return BadTransfer; }
    const uint16_t id = SettingsWire::read16(frame + 1);
    if (frame[0] == 1) {
      reset();
      if (size != 9 || SettingsWire::read16(frame + 3) != SettingsWire::SIZE) return BadTransfer;
      id_ = id; expectedCrc_ = SettingsWire::read32(frame + 5); active_ = true; lastFrame_ = now;
      return Staging;
    }
    if (!active_ || id != id_ || now - lastFrame_ > 10000) { reset(); return BadTransfer; }
    lastFrame_ = now;
    if (frame[0] == 2 && size > 5 && SettingsWire::read16(frame + 3) == received_ &&
        received_ + size - 5 <= SettingsWire::SIZE) {
      memcpy(bytes_ + received_, frame + 5, size - 5); received_ += size - 5;
      return Staging;
    }
    if (frame[0] == 3 && size == 3 && received_ == SettingsWire::SIZE &&
        SettingsWire::crc32(bytes_, SettingsWire::SIZE) == expectedCrc_) {
      active_ = false; ready_ = true; return None; // Caller validates and persists before reporting Saved.
    }
    reset(); return BadTransfer;
  }
  bool ready() const { return ready_; }
  const uint8_t* bytes() const { return bytes_; }
  void reset() { active_ = ready_ = false; received_ = 0; }
 private:
  uint8_t bytes_[SettingsWire::SIZE] = {};
  uint16_t id_ = 0, received_ = 0;
  uint32_t expectedCrc_ = 0, lastFrame_ = 0;
  bool active_ = false, ready_ = false;
};
