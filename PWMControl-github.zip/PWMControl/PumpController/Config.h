#pragma once
#include <stdint.h>

namespace Config {
// Board profile follows the selected Arduino target. Host tests use the C6 defaults.
#if defined(CONFIG_IDF_TARGET_ESP32C3)
// Waveshare ESP32-C3-LCD-1.47: keep USB GPIO18/19 and LCD GPIO3..8 free.
constexpr uint8_t PWM_PIN = 10;
constexpr uint8_t ANALOG_SENSOR_PIN = 0;  // ADC1_CH0
constexpr uint8_t ONE_WIRE_PIN = 1;
#else
// Waveshare ESP32-C6-LCD-1.47 (non-touch).
constexpr uint8_t PWM_PIN = 18;
constexpr uint8_t ANALOG_SENSOR_PIN = 0;  // ADC1_CH0
constexpr uint8_t ONE_WIRE_PIN = 19;
#endif
constexpr bool BLE_ENABLED = true;
constexpr uint8_t SETUP_BUTTON_PIN = 9; // Board BOOT button, active LOW.
constexpr uint32_t SETUP_HOLD_MS = 2000;
constexpr uint32_t SETUP_WINDOW_MS = 120000;

// Enable only after matching the pump's signal specification and interface.
constexpr bool OUTPUT_ENABLED = true;
constexpr bool DEMO_MODE = false; // Synthetic temperature sweep; forces output OFF.
constexpr uint32_t PWM_FREQUENCY_HZ = 25000; // Placeholder: check pump datasheet.
constexpr uint8_t PWM_BITS = 10;
// false: non-inverting 3.3V -> 5V buffer. true: inverting NPN/NMOS stage.
// Duty always means HIGH-time percentage at the pump's input.
constexpr bool INVERT_GPIO = false;

enum class SensorType { NtcTwoPoint, LinearResistance, DS18B20 };
constexpr SensorType SENSOR_TYPE = SensorType::NtcTwoPoint;
// EXAMPLE VALUES ONLY. Replace with measured pairs for your sensor.
constexpr float CAL_TEMP_1_C = 25.0f;
constexpr float CAL_RESISTANCE_1_OHM = 10000.0f;
constexpr float CAL_TEMP_2_C = 50.0f;
constexpr float CAL_RESISTANCE_2_OHM = 3600.0f;
// Divider: 3V3 -> fixed resistor -> ADC -> sensor -> GND.
constexpr float FIXED_RESISTOR_OHM = 10000.0f;
constexpr float DIVIDER_SUPPLY_MV = 3300.0f; // Measure actual 3V3 rail.
// C3/C6 ADC at 12dB has an approximately 0..2500mV useful range.
constexpr float ADC_MIN_MV = 50.0f;
constexpr float ADC_MAX_MV = 2450.0f;
constexpr float SENSOR_MIN_C = -20.0f;
constexpr float SENSOR_MAX_C = 110.0f;

constexpr float START_TEMP_C = 30.0f;
constexpr float STOP_TEMP_C = 28.0f; // Hysteresis prevents repeated starts.
constexpr float FULL_SPEED_TEMP_C = 50.0f;
constexpr float EMERGENCY_TEMP_C = 110.0f; // Immediate full command at the top of the configured sensor range.
constexpr float MIN_RUNNING_PERCENT = 5.0f; // Lowest permitted nonzero curve duty.
constexpr float DEFAULT_START_PERCENT = 35.0f; // Example default; editable through the app.
constexpr float RAMP_PERCENT_PER_SECOND = 10.0f;
constexpr uint32_t START_BOOST_MS = 700; // 100% on start; 0 disables boost.
// Cooling assumption: missing/invalid/stale reading commands 100% immediately.
// For applications where running dry is worse, change this after risk review.
constexpr float SENSOR_FAULT_PERCENT = 100.0f;
constexpr uint32_t SENSOR_STALE_MS = 3000;
constexpr uint32_t SENSOR_SAMPLE_MS = 1000;
constexpr uint32_t DISPLAY_REFRESH_MS = 250;
constexpr uint8_t BACKLIGHT_PERCENT = 40; // Manufacturer recommends <=50%.

static_assert(STOP_TEMP_C < START_TEMP_C, "Stop must be below start");
static_assert(START_TEMP_C < FULL_SPEED_TEMP_C, "Full speed must exceed start");
static_assert(FULL_SPEED_TEMP_C <= EMERGENCY_TEMP_C, "Emergency must exceed full speed");
static_assert(MIN_RUNNING_PERCENT > 0 && MIN_RUNNING_PERCENT <= 100, "Invalid minimum duty");
static_assert(DEFAULT_START_PERCENT >= MIN_RUNNING_PERCENT && DEFAULT_START_PERCENT <= 100, "Invalid default start duty");
static_assert(SENSOR_FAULT_PERCENT >= 0 && SENSOR_FAULT_PERCENT <= 100, "Invalid fault duty");
static_assert(RAMP_PERCENT_PER_SECOND > 0, "Ramp rate must be positive");
static_assert(PWM_BITS > 0 && PWM_BITS <= 14, "Invalid PWM resolution");
static_assert(BACKLIGHT_PERCENT <= 50, "Keep backlight <=50% for this board");
static_assert(FIXED_RESISTOR_OHM > 0 && DIVIDER_SUPPLY_MV > ADC_MAX_MV, "Invalid divider");
}
