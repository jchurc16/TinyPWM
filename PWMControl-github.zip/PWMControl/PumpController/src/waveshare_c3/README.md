# Waveshare C3 display driver

Source: [waveshareteam/ESP32-C3-LCD-1.47](https://github.com/waveshareteam/ESP32-C3-LCD-1.47/tree/6e16df57c20b3b1651c1b6150a1c5b3c418a87f6/example/Arduino/libraries/ESP32_C3_LCD_1in47), revision `6e16df57c20b3b1651c1b6150a1c5b3c418a87f6`.

Copyright 2026 Waveshare. Distributed under Apache-2.0; see LICENSE.
The four driver files are bundled so Arduino IDE and CLI use the same panel initialization, pixel byte order, and I/O expander handling. Modifications: attribution comments and C3-only compilation guards on the two `.cpp` files. The application selects portrait rotation 4 and 40 MHz SPI. Rotation 4 compensates for this panel's native reflected scan direction (the previous landscape layout used rotation 5). The application reapplies rotation after the manufacturer's initialization writes MADCTL.

The manufacturer driver uses a 180 x 320 address window with a 30-column offset for this advertised 172 x 320 display. This is preserved intentionally. Verify the screen edges on hardware.

GPIO5/7/8 provide MOSI/SCLK/DC. GPIO4/3 provide I2C SDA/SCL for the expander at address 0x24. Expander bits 0/1/2 control LCD CS/reset/SD CS; register 0x05 controls backlight PWM. Do not substitute direct ESP32 GPIO numbers for these expander bits.
