#pragma once
#include <atomic>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLESecurity.h>
#include <esp_random.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#if defined(CONFIG_NIMBLE_ENABLED)
#include <host/ble_hs.h>
#endif
#include "SettingsStore.h"
#include "TemperatureSensor.h"
#include "PumpLogic.h"
#include "PumpOutput.h"

class BleControl {
 public:
  static constexpr const char* SERVICE = "3bb84c00-5ec6-4abc-9dc3-0f2b06384000";
  static constexpr const char* SETTINGS = "3bb84c01-5ec6-4abc-9dc3-0f2b06384000";
  static constexpr const char* COMMAND = "3bb84c02-5ec6-4abc-9dc3-0f2b06384000";
  static constexpr const char* STATUS = "3bb84c03-5ec6-4abc-9dc3-0f2b06384000";

  BleControl() : writes_(*this), connections_(*this), security_(*this) {}

  void begin(const ControllerSettings& settings) {
    if (!Config::BLE_ENABLED) return;
    queue_ = xQueueCreate(12, sizeof(Frame));
    if (!queue_) { Serial.println("BLE queue allocation failed"); return; }
    pinMode(Config::SETUP_BUTTON_PIN, INPUT_PULLUP);
    pin_ = 100000 + esp_random() % 900000;
    BLEDevice::init("PWM Pump");
    BLEDevice::setMTU(128);
    BLEDevice::setSecurityCallbacks(&security_);
#if defined(CONFIG_NIMBLE_ENABLED)
    // Arduino 3.3.0's BLESecurity setters have missing static definitions.
    // Configure its underlying NimBLE host directly; server callback supplies the PIN.
    ble_hs_cfg.sm_bonding = 0;
    ble_hs_cfg.sm_mitm = 1;
    ble_hs_cfg.sm_sc = 1;
    ble_hs_cfg.sm_io_cap = BLE_HS_IO_DISPLAY_ONLY;
    ble_hs_cfg.sm_our_key_dist = 0;
    ble_hs_cfg.sm_their_key_dist = 0;
#else
    BLESecurity::setStaticPIN(pin_);
    BLESecurity::setAuthenticationMode(ESP_LE_AUTH_REQ_SC_MITM);
    BLESecurity::setCapability(ESP_IO_CAP_OUT);
#endif
    server_ = BLEDevice::createServer();
    server_->setCallbacks(&connections_);
    BLEService* service = server_->createService(SERVICE);
    uint32_t readProperties = BLECharacteristic::PROPERTY_READ;
    uint32_t writeProperties = BLECharacteristic::PROPERTY_WRITE;
#if defined(CONFIG_NIMBLE_ENABLED)
    readProperties |= BLECharacteristic::PROPERTY_READ_ENC | BLECharacteristic::PROPERTY_READ_AUTHEN;
    writeProperties |= BLECharacteristic::PROPERTY_WRITE_ENC | BLECharacteristic::PROPERTY_WRITE_AUTHEN;
#endif
    settings_ = service->createCharacteristic(SETTINGS, readProperties);
    status_ = service->createCharacteristic(STATUS, readProperties);
    BLECharacteristic* command = service->createCharacteristic(COMMAND, writeProperties);
#if defined(CONFIG_BLUEDROID_ENABLED)
    settings_->setAccessPermissions(ESP_GATT_PERM_READ_ENC_MITM);
    status_->setAccessPermissions(ESP_GATT_PERM_READ_ENC_MITM);
    command->setAccessPermissions(ESP_GATT_PERM_WRITE_ENC_MITM);
#endif
    command->setCallbacks(&writes_);
    publishSettings(settings);
    uint8_t empty[20] = {1}; status_->setValue(empty, sizeof(empty));
    service->start();
    BLEAdvertising* advertising = BLEDevice::getAdvertising();
    advertising->addServiceUUID(SERVICE);
    advertising->setScanResponse(true);
    BLEDevice::startAdvertising();
    ready_ = true;
  }

  // Called exclusively by the application loop. BLE callbacks only enqueue frames.
  bool update(uint32_t now, ControllerSettings& live, SettingsStore& store) {
    if (!ready_) return false;
    const bool pressed = digitalRead(Config::SETUP_BUTTON_PIN) == LOW;
    if (pressed && !wasPressed_) { holdStart_ = now; holdOpened_ = false; }
    if (pressed && !holdOpened_ && now - holdStart_ >= Config::SETUP_HOLD_MS) {
      openedAt_ = now; unlocked_.store(true); holdOpened_ = true;
      Serial.println("BLE setup open for 120 seconds; PIN is shown on screen");
    }
    wasPressed_ = pressed;
    if (unlocked_.load() && now - openedAt_ >= Config::SETUP_WINDOW_MS) {
      unlocked_.store(false); transfer_.reset();
    }
    if (disconnected_.exchange(false)) {
      transfer_.reset(); xQueueReset(queue_);
      BLEDevice::startAdvertising();
    }
    if (overflow_.exchange(false)) { transfer_.reset(); result_ = SettingsTransfer::Busy; }
    bool changed = false;
    Frame frame;
    // Limit work per loop; do not let a central starve pump control.
    for (uint8_t n = 0; n < 4 && xQueueReceive(queue_, &frame, 0) == pdTRUE; ++n) {
      if (frame.size >= 3) transaction_ = SettingsWire::read16(frame.bytes + 1);
      result_ = transfer_.receive(frame.bytes, frame.size, unlocked_.load(), now);
      if (!transfer_.ready()) continue;
      ControllerSettings candidate;
      if (!SettingsWire::decode(transfer_.bytes(), SettingsWire::SIZE, candidate))
        result_ = SettingsTransfer::Invalid;
      else if (!store.save(candidate)) result_ = SettingsTransfer::StorageError;
      else {
        live = candidate; publishSettings(live); changed = true;
        result_ = SettingsTransfer::Saved;
      }
      transfer_.reset();
    }
    return changed;
  }

  void publishStatus(uint32_t now, const TemperatureSensor& sensor, const PumpLogic& pump, const PumpOutput& output) {
    if (!ready_) return;
    uint8_t value[20] = {1};
    value[1] = (sensor.valid(now) ? 1 : 0) | (PumpOutput::enabled() ? 2 : 0) |
               (Config::DEMO_MODE ? 4 : 0) | (unlocked_.load() ? 8 : 0) | (output.ready() ? 16 : 0);
    value[2] = static_cast<uint8_t>(pump.state()); value[3] = result_;
    SettingsWire::writeFloat(value + 4, sensor.temperature());
    SettingsWire::writeFloat(value + 8, output.applied());
    SettingsWire::writeFloat(value + 12, pump.output());
    SettingsWire::write16(value + 16, transaction_);
    SettingsWire::write16(value + 18, secondsRemaining(now));
    status_->setValue(value, sizeof(value));
  }
  bool setupOpen() const { return unlocked_.load(); }
  uint32_t pin() const { return pin_; }
  uint16_t secondsRemaining(uint32_t now) const {
    if (!unlocked_.load()) return 0;
    const uint32_t elapsed = now - openedAt_;
    return elapsed >= Config::SETUP_WINDOW_MS ? 0 : (Config::SETUP_WINDOW_MS - elapsed + 999) / 1000;
  }

 private:
  struct Frame { uint8_t size; uint8_t bytes[20]; };
  class WriteCallbacks : public BLECharacteristicCallbacks {
   public:
    explicit WriteCallbacks(BleControl& parent) : parent_(parent) {}
    // Core 3.3.0 calls both overloads for one write. The base two-argument
    // overload forwards to onWrite(characteristic), duplicating every frame.
    // Handle the one-argument callback once and suppress that forwarding.
#if defined(CONFIG_NIMBLE_ENABLED)
    void onWrite(BLECharacteristic*, ble_gap_conn_desc*) override {}
#elif defined(CONFIG_BLUEDROID_ENABLED)
    void onWrite(BLECharacteristic*, esp_ble_gatts_cb_param_t*) override {}
#endif
    void onWrite(BLECharacteristic* characteristic) override {
      String data = characteristic->getValue();
      if (data.length() > 20) { parent_.overflow_.store(true); return; }
      Frame frame = {}; frame.size = data.length();
      memcpy(frame.bytes, data.c_str(), frame.size);
      if (xQueueSend(parent_.queue_, &frame, 0) != pdTRUE) parent_.overflow_.store(true);
    }
   private: BleControl& parent_;
  };
  class ConnectionCallbacks : public BLEServerCallbacks {
   public:
    explicit ConnectionCallbacks(BleControl& parent) : parent_(parent) {}
    void onDisconnect(BLEServer*) override { parent_.disconnected_.store(true); }
#if defined(CONFIG_NIMBLE_ENABLED)
    uint32_t onPassKeyRequest() override { return parent_.pin_; }
#endif
   private: BleControl& parent_;
  };
  class SecurityCallbacks : public BLESecurityCallbacks {
   public:
    explicit SecurityCallbacks(BleControl& parent) : parent_(parent) {}
    uint32_t onPassKeyRequest() override { return parent_.pin_; }
    void onPassKeyNotify(uint32_t) override {}
    bool onSecurityRequest() override { return parent_.unlocked_.load(); }
    bool onConfirmPIN(uint32_t) override { return false; } // Display-only PIN entry, not numeric comparison.
#if defined(CONFIG_NIMBLE_ENABLED)
    void onAuthenticationComplete(ble_gap_conn_desc*) override {}
#else
    void onAuthenticationComplete(esp_ble_auth_cmpl_t) override {}
#endif
   private: BleControl& parent_;
  };
  void publishSettings(const ControllerSettings& settings) {
    uint8_t bytes[SettingsWire::SIZE]; SettingsWire::encode(settings, bytes);
    settings_->setValue(bytes, sizeof(bytes));
  }
  WriteCallbacks writes_;
  ConnectionCallbacks connections_;
  SecurityCallbacks security_;
  BLEServer* server_ = nullptr;
  BLECharacteristic* settings_ = nullptr;
  BLECharacteristic* status_ = nullptr;
  QueueHandle_t queue_ = nullptr;
  SettingsTransfer transfer_;
  std::atomic<bool> unlocked_{false}, disconnected_{false}, overflow_{false};
  bool ready_ = false, wasPressed_ = false, holdOpened_ = false;
  uint32_t holdStart_ = 0, openedAt_ = 0, pin_ = 0;
  uint16_t transaction_ = 0;
  SettingsTransfer::Result result_ = SettingsTransfer::None;
};
