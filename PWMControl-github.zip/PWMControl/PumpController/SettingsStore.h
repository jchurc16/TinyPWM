#pragma once
#include <Preferences.h>
#include "ControllerSettings.h"

class SettingsStore {
 public:
  bool begin(ControllerSettings& settings) {
    ready_ = preferences_.begin("pump-settings", false);
    if (!ready_) return false;
    uint8_t blob[SettingsWire::SIZE + 4];
    if (preferences_.getBytesLength("config") != sizeof(blob)) return true;
    if (preferences_.getBytes("config", blob, sizeof(blob)) == sizeof(blob) &&
        SettingsWire::read32(blob) == SettingsWire::crc32(blob + 4, SettingsWire::SIZE)) {
      if (!SettingsWire::decode(blob + 4, SettingsWire::SIZE, settings))
        Serial.println("Stored settings invalid: using source defaults");
    } else Serial.println("Stored settings checksum failed: using source defaults");
    return true;
  }
  bool save(const ControllerSettings& settings) {
    if (!ready_ || settings.validationError()) return false;
    uint8_t blob[SettingsWire::SIZE + 4];
    SettingsWire::encode(settings, blob + 4);
    SettingsWire::write32(blob, SettingsWire::crc32(blob + 4, SettingsWire::SIZE));
    return preferences_.putBytes("config", blob, sizeof(blob)) == sizeof(blob);
  }
 private:
  Preferences preferences_;
  bool ready_ = false;
};
