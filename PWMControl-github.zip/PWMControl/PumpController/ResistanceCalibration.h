#pragma once
#include <math.h>

// No Arduino dependency: can also be used by host-side tests.
class ResistanceCalibration {
 public:
  ResistanceCalibration(float t1, float r1, float t2, float r2)
      : t1_(t1), r1_(r1), t2_(t2), r2_(r2) {}

  bool valid(bool ntc) const {
    if (!isfinite(t1_) || !isfinite(t2_) || !isfinite(r1_) || !isfinite(r2_) ||
        t1_ <= -273.15f || t2_ <= -273.15f || r1_ <= 0 || r2_ <= 0 ||
        t1_ == t2_ || r1_ == r2_) return false;
    const float coefficient = ntc ? beta() : 0;
    return !ntc || (isfinite(coefficient) && coefficient > 0); // NTC resistance falls as temperature rises.
  }

  float temperature(float resistance, bool ntc) const {
    if (!valid(ntc) || !isfinite(resistance) || resistance <= 0) return NAN;
    if (!ntc) return t1_ + (resistance - r1_) * (t2_ - t1_) / (r2_ - r1_);
    const float inverseKelvin = 1.0f / (t1_ + 273.15f) + logf(resistance / r1_) / beta();
    return inverseKelvin > 0 ? 1.0f / inverseKelvin - 273.15f : NAN;
  }

  static float resistanceFromDivider(float measuredMv, float supplyMv, float fixedOhms) {
    if (!isfinite(measuredMv) || !isfinite(supplyMv) || !isfinite(fixedOhms) ||
        measuredMv <= 0 || measuredMv >= supplyMv || fixedOhms <= 0) return NAN;
    return fixedOhms * measuredMv / (supplyMv - measuredMv);
  }

 private:
  float beta() const {
    return logf(r1_ / r2_) / (1.0f / (t1_ + 273.15f) - 1.0f / (t2_ + 273.15f));
  }
  float t1_, r1_, t2_, r2_;
};
