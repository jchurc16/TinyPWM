#include "Config.h"
#include "TemperatureSensor.h"
#include "PumpLogic.h"
#include "PumpOutput.h"
#include "Screen.h"
#include "SettingsStore.h"
#include "BleControl.h"

#if !defined(CONFIG_IDF_TARGET_ESP32C6) && !defined(CONFIG_IDF_TARGET_ESP32C3)
#error "Select ESP32C3 Dev Module or ESP32C6 Dev Module with Espressif Arduino core 3.x"
#endif

TemperatureSensor temperatureSensor;
PumpLogic pump;
PumpOutput pumpOutput;
Screen screen;
ControllerSettings settings;
SettingsStore settingsStore;
BleControl bluetooth;

void setup() {
  Serial.begin(115200); // Do not wait for USB: controller also runs standalone.
  if (!pumpOutput.begin()) Serial.println("ERROR: PWM initialization failed");
  if (!settingsStore.begin(settings)) Serial.println("Settings storage unavailable; using source defaults");
  pump.setSettings(settings);
  temperatureSensor.setSettings(settings);
  // Apply configured sensor-fault demand while waiting for the first valid reading.
  pump.update(NAN, false, millis());
  pumpOutput.write(pump.output());
  screen.begin();
  bluetooth.begin(settings);
  Serial.println("PWM pump controller; hold BOOT for 2 seconds for Bluetooth setup");
}

void loop() {
  const uint32_t now = millis();
  if (bluetooth.update(now, settings, settingsStore)) {
    // Discard readings made with the previous calibration before applying the new settings.
    pump.setSettings(settings);
    pump.update(NAN, false, now);
    pumpOutput.write(pump.output());
    temperatureSensor.setSettings(settings);
  }
  temperatureSensor.update(now);
  pump.update(temperatureSensor.temperature(), temperatureSensor.valid(now), now);
  pumpOutput.write(pump.output());
  bluetooth.publishStatus(now, temperatureSensor, pump, pumpOutput);
  screen.update(now, temperatureSensor, pump, pumpOutput,
                bluetooth.setupOpen(), bluetooth.pin(), bluetooth.secondsRemaining(now));

  static uint32_t lastLog = 0;
  if (now - lastLog >= 1000) {
    lastLog = now;
    Serial.printf("temp=%.2fC valid=%d R=%.1fohm ADC=%.0fmV target=%.1f%% demand=%.1f%% output=%.1f%% state=%s\n",
        temperatureSensor.temperature(), temperatureSensor.valid(now), temperatureSensor.resistance(),
        temperatureSensor.voltageMv(), pump.target(), pump.output(), pumpOutput.applied(), pump.stateName());
  }
  delay(10); // Conversion waits are asynchronous; control remains responsive.
}
