# ESP32-C3 / ESP32-C6 water pump controller

Arduino firmware for the **Waveshare ESP32-C3-LCD-1.47** and **ESP32-C6-LCD-1.47**. Confirm the PCB model before wiring: touch versions and other screen boards can have different pins. The portrait display shows large temperature and applied PWM output values, with a red warning triangle replacing the temperature on a sensor fault. A small footer shows status and the Bluetooth setup PIN. This is a signal controller for a pump with its own motor controller.

An [Android Bluetooth companion app](android/README.md) now supports two-point calibration, 2–8 temperature/PWM curve points, stop hysteresis, ramp rate, live telemetry, and validated saves to ESP32 flash. Hold BOOT for two seconds after startup to open its setup window; the screen shows the pairing PIN. The firmware keeps operating when the phone disconnects.

## Repository contents

The repository contains firmware, Android app source, documentation, and the calibration helper. The small Gradle wrapper JAR is included so Android Studio and command-line builds can fetch the pinned Gradle version.

Downloaded toolchains/SDKs, emulator data, Gradle caches, generated firmware/APKs, signing keys, and machine-specific settings are excluded by `.gitignore`. They are regenerated or installed by the setup instructions; they do not belong in the GitHub upload. Open `android/` in Android Studio to configure your own SDK location. APKs and firmware binaries can be attached to a GitHub release separately.

If using the prepared `dist/PWMControl-github.zip`, extract it and upload the contents of its `PWMControl/` folder, including `.gitignore` and `.gitattributes`. The `dist/` directory itself is excluded from Git.


## ESP32-C3-LCD-1.47

The **Waveshare ESP32-C3-LCD-1.47** is supported alongside the original C6 board. Select **ESP32C3 Dev Module**, **4MB flash**, and **USB CDC On Boot: Enabled** using the same pinned core and sensor libraries below. The selected chip automatically chooses the board profile in `Config.h`; no source switch is needed. Other C3 boards need their own display/pin configuration.

| Function | C3 GPIO | C6 GPIO |
| --- | --- | --- |
| Pump PWM before external level interface | 10 | 18 |
| Resistive sensor divider ADC | 0 | 0 |
| Optional DS18B20 data | 1 | 19 |
| BOOT/setup button | 9 | 9 |

For the C3, use **GPIO10 instead of GPIO18** in the PWM wiring diagrams below and **GPIO1 instead of GPIO19** for the optional DS18B20. Keep GPIO18/19 for native USB. Output is enabled in the current `Config.h`; set `OUTPUT_ENABLED = false` to disable the physical PWM output. Calibration, control logic, Bluetooth protocol, and the Android app are shared.

The C3 screen uses the bundled manufacturer driver in `PumpController/src/waveshare_c3/`: LCD MOSI/SCLK/DC are GPIO5/7/8; GPIO4/3 are I2C SDA/SCL. An I/O expander controls LCD CS/reset, SD CS, and backlight. The driver keeps SD deselected. No separate board-driver installation is required. The C6-specific LCD/SD wiring in the Pins section does not apply to the C3.

Build and upload the C3 from the repository root (replace `arduino-cli` with `.\.tools\arduino-cli\arduino-cli.exe` when using the local tool):

```powershell
arduino-cli compile --config-file arduino-cli.yaml --fqbn esp32:esp32:esp32c3:CDCOnBoot=cdc,FlashSize=4M --build-path build/firmware-c3 PumpController
arduino-cli upload --config-file arduino-cli.yaml --fqbn esp32:esp32:esp32c3:CDCOnBoot=cdc,FlashSize=4M --port COM4 --input-dir build/firmware-c3 PumpController
```

Use the matching build directory when switching boards. Hold BOOT for two seconds after startup to show the Bluetooth PIN on the display. Physical display, BLE pairing, sensing, and PWM operation require bench verification after flashing.

Verification (2026-11-08): both C3 and C6 firmware builds pass with core 3.3.0, and the native controller/settings tests pass. The C3 build was uploaded to COM4 with flash hashes verified; live serial telemetry confirmed the application loop running with `output=0.0%`. Sensor readings varied during this check, so temperature accuracy and sensor wiring/calibration are not validated. The physical screen and Bluetooth pairing still need bench verification.

References: [Waveshare C3 documentation](https://docs.waveshare.com/ESP32-C3-LCD-1.47), [manufacturer driver and schematic](https://github.com/waveshareteam/ESP32-C3-LCD-1.47), and [Espressif C3 GPIO restrictions](https://docs.espressif.com/projects/esp-idf/en/v5.1-rc2/esp32c3/api-reference/peripherals/gpio.html).

## Quick start (original C6 board)

1. Install Arduino IDE 2 and add `https://espressif.github.io/arduino-esp32/package_esp32_index.json` to Additional Boards Manager URLs.
2. Install **esp32 by Espressif Systems 3.3.0**. Select **ESP32C6 Dev Module**, **4MB flash**, and **USB CDC On Boot: Enabled**.
3. Install these Library Manager versions: **GFX Library for Arduino 1.6.0** and **DallasTemperature 4.0.5**. For OneWire, remove any Library Manager copy and use **Sketch → Include Library → Add .ZIP Library** with [this pinned upstream ZIP](https://github.com/PaulStoffregen/OneWire/archive/800f26f3ee6eb446a72e013785cac3700e54cc13.zip). It contains the C6 GPIO fix missing from the published 2.3.8 release. Install it even when using a resistive sensor, because the optional digital backend is compiled too.
4. Open `PumpController/PumpController.ino`.
5. Edit `PumpController/Config.h`. For a screen-only trial, set `DEMO_MODE = true`: a synthetic 20–65 °C sweep runs with physical PWM disabled.
6. Upload over USB. If the port is unavailable, hold BOOT, press/release RESET, release BOOT, and select the newly appearing port. Serial output is 115200 baud.
7. For real sensing, set `DEMO_MODE = false`, enter your sensor calibration, and check displayed temperatures and resistance against known values.
8. Match the PWM frequency, voltage interface, polarity, and duty limits to the pump documentation. Set `OUTPUT_ENABLED = true` only after checking the waveform at the pump connector.

`OUTPUT_ENABLED` is currently **true**. The configured sensor-fault policy commands 100% while waiting for the first valid reading and whenever sensing fails. The large PWM OUTPUT value shows the applied electrical command. Percentages represent the electrical command, **not measured RPM or flow**. Disabled output is held at the configured 0% command; a pump may interpret 0% or a missing signal differently.

## Pins (original C6 board)

| Function | GPIO |
| --- | --- |
| Pump control signal, 3.3 V GPIO before external interface | 18 |
| Resistive sensor divider ADC | 0 |
| Optional DS18B20 data | 19 |
| Screen MOSI / SCLK / CS / DC / RESET / backlight | 6 / 7 / 14 / 15 / 21 / 22 |
| SD card CS, held inactive | 4 |

The screen is configured for portrait 172 × 320, with a 34-pixel ST7789 column offset. Backlight is 40%; the manufacturer recommends keeping it at 50% or lower. USB pins 12/13, boot pin 9, and the onboard RGB LED pin 8 are left for their board functions.

## Two-point resistance calibration

Set `SENSOR_TYPE` to `SensorType::NtcTwoPoint` for an NTC thermistor (default), or `SensorType::LinearResistance` for a sensor that is sufficiently linear over the working range. Enter two measured pairs:

These source values are the initial/fallback defaults. After a successful Bluetooth save, persisted settings take precedence over sensor/calibration/curve defaults at boot. Edit or reset those values through the app. Hardware output enable and the other fixed safeguards remain in `Config.h`.

```cpp
constexpr float CAL_TEMP_1_C = 25.0f;
constexpr float CAL_RESISTANCE_1_OHM = 10000.0f;
constexpr float CAL_TEMP_2_C = 50.0f;
constexpr float CAL_RESISTANCE_2_OHM = 3600.0f;
```

**These are illustrative values, not a specification for your sensor.** Choose calibration temperatures that bracket the intended operating range. Disconnect the sensor from powered electronics when measuring resistance, allow it to settle at each known temperature, and use a reference thermometer.

For an NTC, firmware calculates the Beta coefficient from the two pairs and converts resistance using temperatures in Kelvin:

```text
B = ln(R1 / R2) / (1 / T1 - 1 / T2)
T = 1 / (1 / T1 + ln(R / R1) / B)
T_kelvin = T_celsius + 273.15
```

For linear mode: `T = T1 + (R - R1) * (T2 - T1) / (R2 - R1)`.

Two points anchor the selected model; they do not guarantee accuracy between or beyond those points. For wider ranges, use the sensor's resistance table or a three-point Steinhart–Hart calibration. Low-resistance RTDs such as PT100 usually need a dedicated measurement front end; the default 10 kΩ divider is intended for thermistors, not precision RTD measurement.

Generate a printable calibration map with the dependency-free helper:

```powershell
python tools/calibration_map.py --point1 25 10000 --point2 50 3600
python tools/calibration_map.py --point1 0 100 --point2 100 138.5 --linear
```

The helper prints expected resistance and divider voltage at each temperature and flags extrapolation or values outside the configured ADC window. It does not modify the firmware. Use `--temperatures 20 30 40 50 60`, `--fixed-ohms`, and `--supply-mv` to adjust the map.

### Resistive sensor wiring

```text
ESP32 3V3 ---- fixed resistor (10k example) ----+---- sensor ---- GND
                                             |
                                           GPIO0
                                             |
                                      100nF capacitor
                                             |
                                            GND
```

Set `FIXED_RESISTOR_OHM` to its measured value and `DIVIDER_SUPPLY_MV` to the measured 3V3 rail. Firmware uses calibrated `analogReadMilliVolts()` and averages 16 readings. Resistance is `Rfixed * Vadc / (Vsupply - Vadc)`. Do not connect this ADC circuit to a sensor already driven by another controller; use an independent sensor or a suitable measurement interface.

GPIO is not 5 V tolerant. Keep ADC voltage in the C6's usable range, not merely below 3.3 V: this example rejects readings below 50 mV or above 2450 mV. Open/short circuits and ADC saturation cause a sensor fault. Choose the fixed resistor to keep the **entire intended temperature range** inside that window; changing calibration pairs alone cannot correct saturation. Lead resistance, ADC error, supply variation, and thermistor self-heating also affect accuracy.

### Optional DS18B20

Set `SENSOR_TYPE = SensorType::DS18B20`. Connect VDD to 3V3, GND to GND, and DATA to GPIO19 with a 4.7 kΩ pull-up to 3V3. Use three-wire powered operation, not parasite power. The example uses the first discovered DS18B20; use only one probe, or extend the code to select its ROM address. Reads are asynchronous with 750 ms conversion time. Disconnection, out-of-range results, and the 85 °C power-on value are rejected. A genuine reading of exactly 85 °C is therefore conservatively treated as a fault. Resistance calibration does not apply to this digital sensor.

## PWM signal interface

The ESP32 GPIO generates **0–3.3 V**, not 0–5 V. The code controls only the pump's signal input. Power the pump from its own rated supply, and join signal grounds unless using a properly designed isolated interface. Verify whether the pump expects a PWM waveform or a 0–5 V **analog voltage**; this project produces PWM.

### 5 V push-pull input

Use a non-inverting **74AHCT125** buffer powered at regulated 5 V. Its TTL-compatible input accepts a 3.3 V HIGH; a generic 74HC125 at 5 V is not an equivalent guaranteed interface.

```text
GPIO18 ---- 1A    74AHCT125    1Y ---- pump PWM input
GND ------- /1OE              VCC --- regulated 5V
GND ------- GND
```

Add a 100 nF capacitor across buffer VCC/GND, a 10 kΩ pull-down on 1A so reset defaults LOW, and define unused inputs/OE pins per its datasheet. Keep `INVERT_GPIO = false`. Do not connect this 5 V buffer output to a pump signal that is internally pulled up to 12 V. For separately powered equipment, account for power sequencing or use a buffer/interface with appropriate power-off protection.

### Open-drain input or a higher-voltage pull-up

A small logic-level N-channel MOSFET can pull the pump signal LOW. Use a device specified at the available 3.3 V gate drive, rated above the pull-up voltage and sink current:

```text
GPIO18 --- 100R --- gate
                    |       drain ---- pump PWM input ---- pull-up to allowed signal rail
                   10k      source --- common GND
                    |
                   GND
```

Set `INVERT_GPIO = true` to compensate for the transistor's inversion. If the pump supplies an internal pull-up, use it; add an external pull-up only if the pump specification calls for one. A starting design value for an external pull-up is 4.7 kΩ, subject to the required edge speed, cable capacitance, and sink current. Pull up to **5 V or 12 V only when the pump input explicitly permits that voltage**. Motor supply voltage does not establish PWM signal voltage. Scope the waveform at the pump to verify rise time, HIGH level, and duty cycle.

With the shown gate pull-down, the transistor is OFF during ESP32 reset, so the pump input is pulled HIGH (100% HIGH time). Once firmware initializes, a disabled output is driven to 0% HIGH time. If the pump needs a different reset/loss-of-signal behavior, design the interface accordingly. Firmware cannot guarantee an output while the ESP32 is reset or unpowered.

Both interface examples preserve the convention that a higher commanded percentage means a longer HIGH time at the pump. Pumps whose speed increases with LOW time need their own duty mapping. **25 kHz and the example's 35% starting duty are placeholders** until the pump model is known; some pumps run at minimum speed even at 0%. The permitted curve minimum is now 5%, adjustable through the first curve point; the example default remains 35%.

## Control behavior

| Condition | Default command |
| --- | --- |
| Below 30 °C from stopped | 0% |
| Starting at 30 °C | 100% for 700 ms, then calculated duty |
| 30–50 °C | Linear target from 35–100% |
| Already running, 28–30 °C | Remain running at a 35% target |
| 28 °C or lower | Stop command immediately |
| 110 °C or higher (within valid sensor range) | Immediate 100%, bypass ramp |
| Missing, invalid, or stale sensor | Immediate configured fault command (100%) |

Normal duty changes are limited to 10 percentage points per second, with immediate minimum running duty after a boost or unboosted start. Start boost, stopping, sensor faults, and emergency temperature bypass normal ramping. The full-speed temperature sets the **target**; actual demand can lag it during the normal ramp. Temperature is sampled approximately once per second. The control loop runs approximately every 10 ms plus screen/sensor work. Delayed updates are limited to 250 ms worth of ramp change. Timers use wrap-safe unsigned subtraction.

The fault policy assumes a cooling application where continued circulation is preferred. It also applies while waiting for the first valid reading. Set `SENSOR_FAULT_PERCENT` to match the actual application. There is no flow, tachometer, dry-run, or independent overtemperature protection in this starter. A 100% command cannot establish that water is moving.

## Structure and extension

- `Config.h`: board pins, calibration, PWM, and temperature settings.
- `ResistanceCalibration.h`: portable two-point conversion.
- `TemperatureSensor.h`: divider/NTC/linear and DS18B20 acquisition.
- `PumpLogic.h`: hardware-independent curve, ramp, hysteresis, and fault behavior.
- `PumpOutput.h`: LEDC output and GPIO inversion.
- `Screen.h`: small display dashboard, independent of control logic.
- `PumpController.ino`: application loop and serial telemetry.
- `ControllerSettings.h`: runtime calibration and curve model, validation, binary codec, and transactional transfer assembly.
- `SettingsStore.h`: checksummed settings persistence through ESP32 Preferences/NVS.
- `BleControl.h`: PIN-authenticated BLE and the physical setup window.
- `android/`: native Android companion app and build instructions.

The default two-point pump curve can now be replaced by up to eight points through the app, and settings persist without a reflash. Possible additions include Wi-Fi telemetry, a flow sensor, and sensor ROM selection. [The BLE protocol](docs/ble-protocol.md) is documented for other companion clients.

## Command-line build

An Arduino CLI config is included to keep downloaded tools/libraries under `.tools` in this workspace. Run commands from the repository root:

```powershell
arduino-cli core update-index --config-file arduino-cli.yaml
arduino-cli core install esp32:esp32@3.3.0 --config-file arduino-cli.yaml
arduino-cli lib install "GFX Library for Arduino@1.6.0" "DallasTemperature@4.0.5" --config-file arduino-cli.yaml
New-Item -ItemType Directory -Force .tools | Out-Null
Invoke-WebRequest https://github.com/PaulStoffregen/OneWire/archive/800f26f3ee6eb446a72e013785cac3700e54cc13.zip -OutFile .tools/OneWire-C6.zip
arduino-cli lib install --zip-path .tools/OneWire-C6.zip --config-file arduino-cli.yaml
arduino-cli compile --config-file arduino-cli.yaml --fqbn esp32:esp32:esp32c6:CDCOnBoot=cdc,FlashSize=4M --build-path build/firmware PumpController
arduino-cli board list --config-file arduino-cli.yaml
arduino-cli upload --config-file arduino-cli.yaml --fqbn esp32:esp32:esp32c6:CDCOnBoot=cdc,FlashSize=4M --port COM5 --input-dir build/firmware PumpController
```

Use your actual COM port. If OneWire is already installed in this CLI environment, uninstall it before installing the pinned ZIP. The project CLI config permits ZIP installation for this dependency. If using the project-local CLI downloaded during setup, replace `arduino-cli` with `.\.tools\arduino-cli\arduino-cli.exe`. Arduino IDE uses its own package/library directories; the same versions must be installed there if you use the IDE.

## Hardware and API references

Verification: the BLE-enabled firmware compiles for `esp32:esp32:esp32c6:CDCOnBoot=cdc,FlashSize=4M`. Native C++ calibration/control and runtime-settings tests pass. The Java settings codec matches a C++ fixture byte-for-byte, and a Java-generated transfer is accepted by the firmware's portable transaction assembler. The display, sensor wiring, phone-to-board BLE link, persistence across real power cycles, and PWM waveform still require physical bench testing.

- [Waveshare board and pin documentation](https://docs.waveshare.com/ESP32-C6-LCD-1.47)
- [Waveshare schematic](https://files.waveshare.com/wiki/ESP32-C6-LCD-1.47/ESP32-C6-LCD-1.47_schemetics.pdf)
- [Espressif LEDC API](https://docs.espressif.com/projects/arduino-esp32/en/latest/api/ledc.html)
- [Espressif ADC API](https://docs.espressif.com/projects/arduino-esp32/en/latest/api/adc.html)
- [Arduino GFX library](https://github.com/moononournation/Arduino_GFX)
- [TI SN74AHCT125 datasheet](https://www.ti.com/lit/ds/symlink/sn74ahct125.pdf)

## Source archive

This GitHub package excludes all test sources, Android images/screenshots, generated APKs and firmware binaries, SDKs, caches, signing keys, local settings, and Git history. Wiring diagrams in `docs/` are included. Historical verification notes describe checks performed in the development workspace; test programs are not included in this archive.

Extract the ZIP and upload the contents of `PWMControl/`, including `.gitignore` and `.gitattributes`, to the GitHub repository. Recreate this archive with `python tools/package_github.py`.
